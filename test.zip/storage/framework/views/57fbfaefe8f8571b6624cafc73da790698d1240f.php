

<?php $__env->startSection('contenido'); ?>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <div class="mb-5">
                    <label class="form-label">Numero de Orden</label>
                    <input id="nombre" disabled name="nombre" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->numero_solicitud); ?>">
                    <br>
                    <a href="<?php echo e(route('ordene.showProd',$solicitud->id)); ?>" ><img class="card-img-top" title="Adicionar Producto" src="<?php echo e(asset('/imagen/iconos/plus-square.png')); ?>" alt="Card image" style="width:40px"></a>
                    <table class="table table-primary table-striped mt-4" id="ordenesedit">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Nombre del Producto</th>
                                <th scope="col" class="text-center">Imagen</th>
                                <th scope="col" class="text-center">Precio</th>
                                <th scope="col" class="text-center">Cantidad Pedida</th>
                                <th scope="col" class="text-center">Disponibilidad</th>
                                <th scope="col" class="text-center">Acciones</th>
                            </tr>            
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitud->Ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($orden->Producto->nombre); ?></td>
                                <td class="text-center"><img src="<?php echo e(asset($orden->Producto->imagen)); ?>"/></td>
                                <td class="text-center"><?php echo e($orden->Producto->precio); ?></td>
                                <form action="<?php echo e(route('ordene.updatecant',$orden->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <td class="text-center">
                                        <input id="disponibilidad" class="text-center" name="disponibilidad" type="number" value="<?php echo e($orden->cantidad); ?>"/>
                                        <button type="submit" class="btn btn-info text-center"><img class="card-img-top" title="Actualizar precio o disponibilidad" src="<?php echo e(asset('/imagen/iconos/guardar.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></button>
                                    </td>
                                </form>
                                <td class="text-center"><?php echo e($orden->Producto->disponibilidad); ?></td>   
                                <form action="<?php echo e(route('ordene.eliminarorden',$orden->id)); ?>" method="POST" class="formEliminar">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?> 
                                    <td class="text-center">
                                        <input title="Eliminar Producto" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
                                    </td> 
                                </form>                             
                                                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <label class="form-label">Nombre del Cliente</label>
                    <input id="nombre_cliente" disabled name="nombre_cliente" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->nombre_cliente); ?>">
                    <label class="form-label">Telefono</label>
                    <input id="telefono" disabled name="telefono" type="number" class="form-control" tabindex="1" value="<?php echo e($solicitud->telefono); ?>">
                    <label class="form-label">Correo</label>
                    <input id="correo" disabled name="correo" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->correo); ?>">
                    <label class="form-label">Direccion</label>
                    <input id="direccion" disabled name="direccion" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->direccion); ?>">
                    
                    <br>
                </div>
                </div>                        
                <a href="<?php echo e(route('orden.index')); ?>" class="btn btn-secondary" tabindex="3">Regresar</a>           
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/configuracion.js')); ?>"></script>
    <?php if(session('disponible') == 'ok'): ?>
        <script type="application/javascript">
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/ordene/edit.blade.php ENDPATH**/ ?>