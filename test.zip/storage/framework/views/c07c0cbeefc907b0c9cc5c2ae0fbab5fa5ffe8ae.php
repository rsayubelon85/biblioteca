

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-md-center">
    <div class="ml-2 col-sm-4">
    <div id="msg"></div>

    </div>
    </div>
</div>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR PRECIO O DISPONIBILIDAD DEL PRODUCTO</h2>
                <form action="<?php echo e(route('products.updatepd',$nombreProducto)); ?>" method="POST" id="image-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" disabled tabindex="1" value="<?php echo e(old('nombreProducto',$nombreProducto)); ?>">
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="form-label">Precio</label>
                    <input id="precio" name="precio" type="number" step="0.01" class="form-control" tabindex="1" value="<?php echo e(old('precio',$precio)); ?>">
                    <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="form-label">Disponibilidad</label>
                    <input id="disponibilidad" name="disponibilidad" type="number" class="form-control" tabindex="1" value="<?php echo e(old('disponibilidad',$disponibilidad)); ?>">
                    <?php $__errorArgs = ['disponibilidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>           
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/producto/editpd.blade.php ENDPATH**/ ?>