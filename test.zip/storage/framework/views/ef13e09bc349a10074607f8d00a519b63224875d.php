

<?php $__env->startSection('contenido'); ?>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>ASIGNAR TARIFA</h2>
                <form action="<?php echo e(route('tarifarios.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-5">
                        <label class="form-label">Tarifa</label>
                        <div class="col-auto">
                            <select name="tarifa" id="tarifa" class="form-control selectpicker" title="Seleccionar Tarifa">
                                <?php $__currentLoopData = $tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tarifa->id); ?>"><?php echo e($tarifa->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>  
                        </div>                        
                        <table class="table table-primary table-striped mt-4" id="tarifarios">
                            <thead>
                                <tr>
                                    <th scope="col">Plan</th>
                                    <th scope="col">Moneda Base</th>
                                    <th scope="col">Valor del Cambio</th>
                                    <th scope="col">Moneda Secundaria</th>                        
                                    <th scope="col">Escoger</th> 
                                </tr>            
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($plan->id); ?></td>
                                    <td><?php echo e($plan->MonedaPri->nombre); ?></td>
                                    <td><?php echo e($plan->valor_cambio); ?></td>  
                                    <td><?php echo e($plan->MonedaSec->nombre); ?></td>      
                                    <td><input type="checkbox" id="plan[]" name="plan[]" value="<?php echo e($plan->id); ?>"/></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                                                    
                        <br>                    
                    </div>                    
                    <a href="<?php echo e(route('tarifarios.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/configuracion.js')); ?>"></script>
    <script>
        $('#tarifarios').DataTable({
            responsive: true,
            autoWidth: false
        });
    </script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/tarifario/create.blade.php ENDPATH**/ ?>