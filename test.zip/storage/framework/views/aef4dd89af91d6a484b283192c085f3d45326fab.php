<?php if(Session::get('TypeController') == 'Categoria'): ?>
    <form action="<?php echo e(route('categorias.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="<?php echo e(route('categorias.edit',$id)); ?>" ><img class="card-img-top" title="Editar Categoria" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Categoria" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>    
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Moneda'): ?>
    <form action="<?php echo e(route('monedas.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="<?php echo e(route('monedas.edit',$id)); ?>" ><img class="card-img-top" title="Editar Moneda" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Moneda" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Tarifa'): ?>
    <form action="<?php echo e(route('tarifas.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="<?php echo e(route('tarifas.edit',$id)); ?>" ><img class="card-img-top" title="Editar Tarifa" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Tarifa" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Plan'): ?>
    <form action="<?php echo e(route('plans.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="<?php echo e(route('plans.edit',$id)); ?>" ><img class="card-img-top" title="Editar Plan" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Plan" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Tarifario'): ?>
    <form action="<?php echo e(route('tarifarios.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="<?php echo e(route('tarifarios.edit',$id)); ?>" ><img class="card-img-top" title="Editar Tarifario" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Tarifario" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Producto'): ?>
    <form action="<?php echo e(route('ordene.destroy',$id)); ?>" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col" style="width: 20px">
                <a href="<?php echo e(route('productos.edit',$id)); ?>" ><img class="card-img-top" title="Editar Producto" src="<?php echo e(asset('/imagen/iconos/pencil-squarenaranja.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col" style="width: 20px">
                <a href="<?php echo e(route('product.editpd',$id)); ?>" ><img class="card-img-top" title="Actualizar precio o disponibilidad" src="<?php echo e(asset('/imagen/iconos/editimg2.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col" style="width: 20px">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>    
                <input title="Eliminar Producto" src="<?php echo e(asset('/imagen/iconos/trashrojo.png')); ?>"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
<?php endif; ?>
<?php if(Session::get('TypeController') == 'Catalogo'): ?>
    
    <input type="checkbox" id="chbox" onclick="window.location='<?php echo e(route('catalogo.select',$id)); ?>'" style="transform: scale(2.0)"/>
 
<?php endif; ?>

<?php if(Session::get('TypeController') == 'Ordene'): ?>
  
    <input type="checkbox" id="chboxconfirm" onclick="window.location='<?php echo e(route('ordene.confirmar',$id)); ?>'" style="transform: scale(2.0)"/>
<?php endif; ?>

<script>
$(document).ready(function () {
    $('.formEliminar').submit(function(e){
        e.preventDefault(); 
        
        Swal.fire({
            title: 'Está usted seguro?',
            text: "No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, borrarlo!',
            cancelButtonText: 'Cancelar'
            }).then((result) => {
            if (result.isConfirmed) {
                
                this.submit();
            }
        })
    });
})    
</script>


<?php /**PATH C:\xampp\htdocs\catalogo\resources\views/actionsd.blade.php ENDPATH**/ ?>