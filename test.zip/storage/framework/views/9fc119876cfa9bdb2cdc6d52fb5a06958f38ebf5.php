

<?php $__env->startSection('contenido'); ?>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR PRODUCTO</h2>
                <form action="<?php echo e(route('productos.update',$producto)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="<?php echo e(old('nombre',$producto->nombre)); ?>">
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Disponibilidad</label>
                        <input id="disponibilidad" name="disponibilidad" type="number" class="form-control" tabindex="1" value="<?php echo e(old('disponibilidad',$producto->disponibilidad)); ?>">
                        <?php $__errorArgs = ['disponibilidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Precio</label>
                        <input id="precio" name="precio" type="number" step="0.01" class="form-control" tabindex="1" value="<?php echo e(old('precio',$producto->precio)); ?>">
                        <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Seleccionar Categoria</label><br>
                        <select name="categorias[]" id="categorias" class="form-control selectpicker"  data-style="btn-primary" title="Seleccionar Categorias">
                            <option value="<?php echo e($producto->categoria->id); ?>"><?php echo e($producto->categoria->nombre); ?></option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                        <br>
                        <label class="form-label">Descripción</label>
                        <textarea id="descripcion" name="descripcion" rows="5" type="text" class="form-control" tabindex="1" ><?php echo e(old('descripcion',$producto->descripcion)); ?></textarea>
                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <input type="file" name="imagen" class="imagen" hidden>
                            <div class="input-group my-3">
                                <input type="text" class="form-control" disabled placeholder="Cargar imagen" id="imagen">
                                <div class="input-group-append">
                                    <button type="button" class="browse btn btn-primary">Browse...</button>
                                </div>
                            </div>
                            <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small>*<?php echo e($message); ?></small>
                                <br>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <img src="<?php echo e(asset('/imagen/'.$producto->imagen)); ?>" id="preview" class="img-thumbnail">
                        </div>
                        <br>
                    </div>
                    
                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).on("click", ".browse", function() {
            var file = $(this).parent().parent().parent().find(".imagen");
            file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#imagen").val(fileName);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                // get loaded data and render thumbnail.
                document.getElementById("preview").src = e.target.result;
            };
            // read the image file as a data URL.
            reader.readAsDataURL(this.files[0]);

            /*$("#image-form").on("submit", function() {
                $("#msg").html('<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> Espere por favor...!</div>');
                $.ajax({
                    type: "PUT",
                    url: "<?php echo e(url('productos/{producto}/update')); ?>",
                    data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false, // To unable request pages to be cached
                    processData: false, // To send DOMDocument or non processed data file it is set to false
                    success: function(data) {
                        if (data == 1 || parseInt(data) == 1) {
                            $("#msg").html(
                                '<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Datos actualizados con éxito.</div>'
                            );
                        } else {
                            $("#msg").html(
                                '<div class="alert alert-info"><i class="fa fa-exclamation-triangle"></i> La extensión no es buena, solo prueba con <strong>GIF, JPG, PNG, JPEG</strong>.</div>'
                            );
                        }
                    },
                    error: function(data) {
                        $("#msg").html(
                            '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Hay algo mal..</div>'
                        );
                    }
                });
            });*/
        });    
    </script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/producto/edit.blade.php ENDPATH**/ ?>