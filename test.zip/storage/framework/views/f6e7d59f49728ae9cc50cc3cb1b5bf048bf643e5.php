

<?php $__env->startSection('contenido'); ?>
    <a href="<?php echo e(route('productos.create')); ?>" ><img class="card-img-top" title="Crear Producto" src="<?php echo e(asset('/imagen/iconos/plus-square.png')); ?>" alt="Card image" style="width:40px"></a>    
    <input type="text" id="tipo_config" value="producto_index" hidden="hidden">
    <div class="card">
        <div class="card-body">
            <table class="table table-primary table-striped mt-4" id="productos">
                <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Imagen</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Disponibilidad</th>
                        <th scope="col">Categoría</th>
                        <th scope="col" style="width: 100px">Acciones</th>                        
                        <th scope="col">Descripción</th>
                    </tr>            
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/configuracion.js')); ?>"></script>
    <script type="application/javascript">
        $(document).ready(function () {
            $('#productos').DataTable({
                "responsive": true,
                "autoWidth": false,
                "serverSide": true,
                "language": {
                    "lengthMenu":   'Mostrando <select class="custom-select custom-select-sm form-control form-control-sm"> '+
                                    '<option value="10">10</option>'+
                                    '<option value="25">25</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="100">100</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> registros por página',
                    "zeroRecords": "Registros no encontrados - disculpe",
                    "emptyTable": "No hay datos",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay coincidencias",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "search":"Buscar",
                    "loadingRecords":"Cargando...",
                    "processing":"Procesando...",
                    "paginate":{
                        "first": "Primero",
                        "last": "Último",                        
                        "next":"Siguiente",
                        "previous":"Anterior"
                    },
                },
                "ajax": "<?php echo e(url('productos/prod')); ?>",
                "columns": [
                    {data: 'nombreProducto'},
                    {
                        data:"imagen",
                        render:function(data,type,row) {
                            return '<center><img src="'+data+'" width="120" height="120"></center>'                            
                        }
                    },
                    {data: 'precio'},
                    {data: 'disponibilidad'},
                    {data: 'nombreCategoria'},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                    {data: 'descripcion'},
                ]
            });
        })
    </script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire(
                    'Eliminado!',
                    'Su registro ha sido eliminado.',
                    'exito'
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/producto/index.blade.php ENDPATH**/ ?>