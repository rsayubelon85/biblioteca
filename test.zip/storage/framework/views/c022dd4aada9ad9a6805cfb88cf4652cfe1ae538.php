

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-md-center">
    <div class="ml-2 col-sm-4">
    <div id="msg"></div>

    </div>
    </div>
</div>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR IMAGEN DEL PRODUCTO</h2>
                <form method="POST" action="<?php echo e(route('products.updateimg',$producto)); ?>" id="image-form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <input type="file" name="file" class="file">
                    <div class="input-group my-3">
                    <input type="text" class="form-control" disabled placeholder="Cargar imagen" id="file">
                    <div class="input-group-append">
                        <button type="button" class="browse btn btn-primary">Buscar...</button>
                    </div>
                    </div>
                    </div>
                    <div class="form-group">
                        <img src="<?php echo e(asset('/imagen/'.$producto->imagen)); ?>" name="preview" id="preview" class="img-thumbnail">
                    </div>
                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>           
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).on("click", ".browse", function() {
            var file = $(this)
            .parent()
            .parent()
            .parent()
            .find(".file");
            file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#file").val(fileName);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                // get loaded data and render thumbnail.
                document.getElementById("preview").src = e.target.result;
            };
            // read the image file as a data URL.
            reader.readAsDataURL(this.files[0]);

            /*$("#image-form").on("submit", function() {
                $("#msg").html('<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> Espere por favor...!</div>');
                $.ajax({
                    type: "PUT",
                    url: "<?php echo e(url('productos/{producto}/update')); ?>",
                    data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false, // To unable request pages to be cached
                    processData: false, // To send DOMDocument or non processed data file it is set to false
                    success: function(data) {
                        if (data == 1 || parseInt(data) == 1) {
                            $("#msg").html(
                                '<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Datos actualizados con éxito.</div>'
                            );
                        } else {
                            $("#msg").html(
                                '<div class="alert alert-info"><i class="fa fa-exclamation-triangle"></i> La extensión no es buena, solo prueba con <strong>GIF, JPG, PNG, JPEG</strong>.</div>'
                            );
                        }
                    },
                    error: function(data) {
                        $("#msg").html(
                            '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Hay algo mal..</div>'
                        );
                    }
                });
            });*/
        });    
    </script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/producto/editimg.blade.php ENDPATH**/ ?>