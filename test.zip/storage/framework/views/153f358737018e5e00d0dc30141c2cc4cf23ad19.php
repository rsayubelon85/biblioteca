
<?php $__env->startSection('contenido'); ?>
    <h2>EDITAR PLAN</h2>
    <form action="<?php echo e(route('plans.update',$plan)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-row align-items-center">
            <div class="col-auto">
                <label class="sr-only" for="inputmoneda">Moneda Base: <?php echo e($plan->MonedaPri->nombre); ?></label>                                            
            </div>
            <div class="col-auto">
                <input id="valor_cambio" name="valor_cambio" type="number" step="0.01" class="form-control" value="<?php echo e(old('valor_cambio',$plan->valor_cambio)); ?>">     
            </div>
            <div class="col-auto">
                <select name="moneda_select[]" id="moneda_select" class="form-control selectpicker" title="Seleccionar Moneda">
                    <option value="<?php echo e($plan->MonedaSec->id); ?>"><?php echo e($plan->MonedaSec->nombre); ?></option>
                    <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda_sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($moneda_sec->id); ?>"><?php echo e($moneda_sec->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>  
            </div>                                    
        </div>

        <a href="<?php echo e(route('plans.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/plan/edit.blade.php ENDPATH**/ ?>