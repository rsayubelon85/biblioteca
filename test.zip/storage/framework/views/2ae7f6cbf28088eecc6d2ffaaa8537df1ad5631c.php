

<?php $__env->startSection('contenido'); ?>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>CREAR TARIFA</h2>
                <form action="<?php echo e(route('tarifas.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="<?php echo e(old('nombre')); ?>">
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Fecha Inicial</label>
                        <input id="fecha_inicial" name="fecha_inicial" type="date" class="form-control" tabindex="1" value="<?php echo e(old('fecha_inicial')); ?>">
                        <?php $__errorArgs = ['fecha_inicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Fecha Final</label>
                        <input id="fecha_final" name="fecha_final" type="date" class="form-control" tabindex="1" value="<?php echo e(old('fecha_final')); ?>">
                        <?php $__errorArgs = ['fecha_inicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="form-label">Porciento de descuento o aumento al precio del producto (%)</label>
                        <input id="variacion_precio" name="variacion_precio" type="number" step="0.01" class="form-control" tabindex="1" value="<?php echo e(old('fecha_final',0)); ?>">
                        <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br>
                            <small>*<?php echo e($message); ?></small>
                            <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <table class="table table-primary table-striped mt-4">
                            <thead>
                                <tr>
                                    <th scope="col">Lunes</th>
                                    <th scope="col">Martes</th>
                                    <th scope="col">Miércoles</th>
                                    <th scope="col">Jueves</th>
                                    <th scope="col">Viernes</th>
                                    <th scope="col">Sábado</th>
                                    <th scope="col">Domingo</th>
                                </tr>            
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input name="lunes" type="checkbox"></td>
                                    <td><input name="martes" type="checkbox"></td>
                                    <td><input name="miercoles" type="checkbox"></td>
                                    <td><input name="jueves" type="checkbox"></td>
                                    <td><input name="viernes" type="checkbox"></td>
                                    <td><input name="sabado" type="checkbox"></td>
                                    <td><input name="domingo" type="checkbox"></td>                                                          
                                </tr>                        
                            </tbody>
                        </table>                                                    
                        <br>                    
                    </div>
                    
                    <a href="<?php echo e(route('tarifas.index')); ?>" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/tarifa/create.blade.php ENDPATH**/ ?>