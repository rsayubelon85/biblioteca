

<?php $__env->startSection('contenido'); ?>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>ORDEN:</h2>
                <div class="mb-5">
                    <label class="form-label">Numero de Orden</label>
                    <input id="nombre" disabled name="nombre" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->numero_solicitud); ?>">
                    <table class="table table-primary table-striped mt-4" id="ordenesselect">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Nombre del Producto</th>
                                <th scope="col" class="text-center">Imagen</th>
                                <th scope="col" class="text-center">Precio</th>
                                <th scope="col" class="text-center">Cantidad Pedida</th>
                                <th scope="col" class="text-center">Disponibilidad</th>
                            </tr>            
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitud->Ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($orden->Producto->nombre); ?></td>
                                <td class="text-center"><img src="<?php echo e(asset($orden->Producto->imagen)); ?>"/></td>
                                <td class="text-center"><?php echo e($orden->Producto->precio); ?></td>
                                <td class="text-center"><?php echo e($orden->cantidad); ?></td>
                                <td class="text-center"><?php echo e($orden->Producto->disponibilidad); ?></td>                                 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <label class="form-label">Nombre del Cliente</label>
                    <input id="nombre_cliente" disabled name="nombre_cliente" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->nombre_cliente); ?>">
                    <label class="form-label">Telefono</label>
                    <input id="telefono" disabled name="telefono" type="number" class="form-control" tabindex="1" value="<?php echo e($solicitud->telefono); ?>">
                    <label class="form-label">Correo</label>
                    <input id="correo" disabled name="correo" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->correo); ?>">
                    <label class="form-label">Direccion</label>
                    <input id="direccion" disabled name="direccion" type="text" class="form-control" tabindex="1" value="<?php echo e($solicitud->direccion); ?>">
                    
                    <br>
                </div>
                </div>                        
                <a href="<?php echo e(route('orden.index')); ?>" class="btn btn-secondary" tabindex="3">Regresar</a>           
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
        $(document).on("click", ".browse", function() {
            var file = $(this).parent().parent().parent().find(".imagen");
            file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#imagen").val(fileName);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                // get loaded data and render thumbnail.
                document.getElementById("preview").src = e.target.result;
            };
            // read the image file as a data URL.
            reader.readAsDataURL(this.files[0]);
        });    
</script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/ordene/show.blade.php ENDPATH**/ ?>