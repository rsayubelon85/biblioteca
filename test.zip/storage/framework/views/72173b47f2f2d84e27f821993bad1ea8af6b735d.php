<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Catálogo</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/cloudflare.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap5.min.css')); ?>">
    <style>
      .file {
      visibility: hidden;
      position: absolute;
      }   
    </style>

  </head>
  <body>
    <nav class="navbar navbar-expand-lg text-center" style="background-color: #e3f2fd;">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <img src="<?php echo e(asset('/imagen/icono.png')); ?>" style="width: 40px"/>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo e(route('catalogo.index')); ?>" id="nav_login">Autenticarse</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo e(route('catalogo.index')); ?>" id="nav_catalogo">Catálogo</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('productos.index')); ?>" id="nav_producto">Productos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('orden.index')); ?>" id="nav_ordene">Órdenes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('categorias.index')); ?>" id="nav_usuario">Usuarios</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Tarifas
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('tarifas.index')); ?>">Tarifas</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(route('plans.index')); ?>">Plan de Tarifas</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(route('tarifarios.index')); ?>">Asignar Tarifas a Plan </a></li>
              </ul>
            </li>            
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Nomencladores
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('categorias.index')); ?>">Categorías</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(route('monedas.index')); ?>">Monedas</a></li>
              </ul>
            </li>
            
            <!--
            <li class="nav-item">
              <a class="nav-link disabled">Disabled</a>
            </li>-
          </ul>
          <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>-->
        </div>
      </div>
    </nav>    
    <div class="container">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div> 
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>       
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script><!--https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"-->
    <script src="<?php echo e(asset('js/sweetalert2_11.js')); ?>"></script>

    <div class="container">
        <?php echo $__env->yieldContent('js'); ?>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>