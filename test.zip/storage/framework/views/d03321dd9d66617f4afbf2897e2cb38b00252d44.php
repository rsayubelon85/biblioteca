

<?php $__env->startSection('contenido'); ?>
    <a href="productos/create" class="btn btn-primary">CREAR</a>
    <input type="text" id="tipo_config" value="producto_index" hidden="hidden">
    <div class="card">
        <div class="card-body">
            <table class="table table-primary table-striped mt-4" id="productos">
                <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Disponibilidad</th>
                        <th scope="col">Categoria</th>
                        <th scope="col">Acciones</th>
                    </tr>            
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td><?php echo e($producto->precio); ?></td>
                        <td><?php echo e($producto->disponibilidad); ?></td>
                        <td><?php echo e($producto->categoria->nombre); ?></td>        
                        <td>
                            <form action="<?php echo e(route('productos.destroy',$producto->id)); ?>" method="POST" class="formEliminar">
                                <a href="./productos/<?php echo e($producto->id); ?>/edit" class="btn btn-info">Editar</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Borrar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/configuracion.js')); ?>"></script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            Swal.fire(
                    'Eliminado!',
                    'Su registro ha sido eliminado.',
                    'exito'
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/productos/index.blade.php ENDPATH**/ ?>