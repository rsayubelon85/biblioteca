<?php if(Session::get('TypeController') == 'Ordene'): ?>
    <input type="checkbox" name="checkbox"/>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\catalogo\resources\views/actionsc.blade.php ENDPATH**/ ?>