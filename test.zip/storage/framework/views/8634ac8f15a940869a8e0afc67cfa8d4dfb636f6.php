

<?php $__env->startSection('contenido'); ?>
    <meta http-equiv='cache-control' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <meta http-equiv='pragma' content='no-cache'>
    <input type="text" id="tipo_config" value="catalogo_index" hidden="hidden">
    <div class="card">
        <div class="card-body">
            <table class="table table-primary table-striped mt-4" id="productos">
                <thead>
                    <tr>
                        <th></th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Imagen</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Disponibilidad</th>
                        <th scope="col">Categoría</th>
                        <th scope="col">Descripción</th>
                    </tr>            
                </thead>
            </table>
        </div>
    </div>
    <div class="card text-center">
        <div class="card-body">
            <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor" class="-mt-px w-5 h-5 text-gray-400" style="height: 40" style="width: 40">
                <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <b class="ml-1 underline">Carrito</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <b class="ml-1 underline">Orden de Compra:</b>
            <b class="ml-1 underline"><?php echo e($numero_solicitud); ?></b>&nbsp&nbsp&nbsp&nbsp
            <br>
            <b class="ml-1 underline" style="color: brown">Total General:</b>
            <b class="ml-1 underline text-rigth" style="color: brown"><?php echo e($totalGeneralStr); ?></b>
            <button id="btnformcontact" onclick="MostrarFormContact()" class="btn btn-ligth btn-outline-info">Completar</button>
            <table class="table table-primary table-striped mt-4" id="productosselect">
                <thead>
                    <tr>
                        <th scope="col" class="text-center" hidden>Id</th>
                        <th scope="col" class="text-center">Nombre</th>
                        <th scope="col" class="text-center">Imagen</th>
                        <th scope="col" class="text-center">Precio</th>
                        <th scope="col" class="text-center">Cantidad</th>
                    </tr>            
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productosSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td hidden><?php echo e($producto->id); ?></td>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td><img src="<?php echo e(asset($producto->imagen)); ?>"/></td>
                        <td><?php echo e($producto->precio); ?></td>
                        <form action="<?php echo e(route('catalogo.select',$producto->id)); ?>" method="GET">
                            <td>
                                <input id="disponibilidad" name="disponibilidad" type="number" value="<?php echo e($producto->disponibilidad); ?>"/>
                                <button type="submit" class="btn btn-info"><img class="card-img-top" title="Actualizar precio o disponibilidad" src="<?php echo e(asset('/imagen/iconos/guardar.png')); ?>" alt="Card image" style="width:30px" style="display: inline-block"></button>
                            </td>
                        </form> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card" id="formcontac" hidden>
        <div class="card-body">
            <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor" class="-mt-px w-5 h-5 text-gray-400" style="height: 40" style="width: 40">
                <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <b class="ml-1 underline">Datos del cliente</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <b class="ml-1 underline">Orden de Compra:</b>
            <b class="ml-1 underline"><?php echo e($numero_solicitud); ?></b>&nbsp&nbsp&nbsp&nbsp
            <b class="ml-1 underline" style="color: brown">Total General:</b>
            <b class="ml-1 underline text-rigth" style="color: brown"><?php echo e($totalGeneralStr); ?></b>
            
            <form action="<?php echo e(route('catalogo.updatesolicitud',$numero_solicitud)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-5">
                    <label class="form-label">Nombre</label>
                    <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="<?php echo e(old('nombre')); ?>">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="form-label">Teléfono</label>
                    <input id="telefono" name="telefono" type="number" class="form-control" tabindex="1" value="<?php echo e(old('telefono')); ?>">
                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="form-label">Correo Electrónico</label>
                    <input id="correo" name="correo" type="text" class="form-control" tabindex="1" value="<?php echo e(old('correo')); ?>">
                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    <label class="form-label">Dirección</label>
                    <input id="direccion" name="direccion" type="text" class="form-control" tabindex="1" value="<?php echo e(old('direccion')); ?>">
                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                        <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary">Enviar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/configuracion.js')); ?>"></script>
    <script type="application/javascript">
        $(document).ready(function () {
            $('#productos').DataTable({
                "responsive": true,
                "autoWidth": false,
                "serverSide": true,
                "language": {
                    "lengthMenu":   'Mostrando <select class="custom-select custom-select-sm form-control form-control-sm"> '+
                                    '<option value="10">10</option>'+
                                    '<option value="25">25</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="100">100</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> registros por página',
                    "zeroRecords": "Registros no encontrados - disculpe",
                    "emptyTable": "No hay datos",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay coincidencias",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "search":"Buscar",
                    "loadingRecords":"Cargando...",
                    "processing":"Procesando...",
                    "paginate":{
                        "first": "Primero",
                        "last": "Último",                        
                        "next":"Siguiente",
                        "previous":"Anterior"
                    },
                },
                "ajax": "<?php echo e(url('catalogo/prod')); ?>",
                "columns": [
                    {data: 'action', name: 'action', orderable: false, searchable: false}, 
                    {data: 'nombreProducto'},
                    {
                        data:"imagen",
                        render:function(data,type,row) {
                            return '<center><img src="'+data+'" width="120" height="120"></center>'                            
                        }
                    },
                    {data: 'precio'},
                    {data: 'disponibilidad'},
                    {data: 'nombreCategoria'},
                    {data: 'descripcion'},
                ]
            });
            $('#productosselect').DataTable({
                "responsive": true,
                "autoWidth": false,
                "language": {
                    "lengthMenu":   'Mostrando <select class="custom-select custom-select-sm form-control form-control-sm"> '+
                                    '<option value="10">10</option>'+
                                    '<option value="25">25</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="100">100</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> registros por página',
                    "zeroRecords": "Registros no encontrados - disculpe",
                    "emptyTable": "No hay datos",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay coincidencias",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "search":"Buscar",
                    "loadingRecords":"Cargando...",
                    "processing":"Procesando...",
                    "paginate":{
                        "first": "Primero",
                        "last": "Último",                        
                        "next":"Siguiente",
                        "previous":"Anterior"
                    },
                },
            });

        })
    </script>
    <?php if(session('eliminar') == 'ok'): ?>
        <script>
            var type = "<?php echo e(Session::get('type')); ?>";
            var title = "<?php echo e(Session::get('title')); ?>";
            var message = "<?php echo e(Session::get('message')); ?>";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/index.blade.php ENDPATH**/ ?>