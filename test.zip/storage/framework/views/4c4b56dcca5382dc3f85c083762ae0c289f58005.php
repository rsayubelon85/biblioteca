<form>
    <input type="checkbox" id="chbox" style="transform: scale(2.0)"/>
</form><?php /**PATH C:\xampp\htdocs\catalogo\resources\views/actionsconfirm.blade.php ENDPATH**/ ?>