@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <div class="mb-5">
                    <label class="form-label">Numero de Orden</label>
                    <input id="nombre" disabled name="nombre" type="text" class="form-control" tabindex="1" value="{{$solicitud->numero_solicitud}}">
                    <br>
                    <a href="{{route('ordene.showProd',$solicitud->id)}}" ><img class="card-img-top" title="Adicionar Producto" src="{{asset('/imagen/iconos/plus-square.png')}}" alt="Card image" style="width:40px"></a>
                    <table class="table table-primary table-striped mt-4" id="ordenesedit">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Nombre del Producto</th>
                                <th scope="col" class="text-center">Imagen</th>
                                <th scope="col" class="text-center">Precio</th>
                                <th scope="col" class="text-center">Cantidad Pedida</th>
                                <th scope="col" class="text-center">Disponibilidad</th>
                                <th scope="col" class="text-center">Acciones</th>
                            </tr>            
                        </thead>
                        <tbody>
                            @foreach ($solicitud->Ordenes as $orden)
                            <tr>
                                <td class="text-center">{{$orden->Producto->nombre}}</td>
                                <td class="text-center"><img src="{{asset($orden->Producto->imagen)}}"/></td>
                                <td class="text-center">{{$orden->Producto->precio}}</td>
                                <form action="{{route('ordene.updatecant',$orden->id)}}" method="POST">
                                    @csrf
                                    @method('put')
                                    <td class="text-center">
                                        <input id="disponibilidad" class="text-center" name="disponibilidad" type="number" value="{{$orden->cantidad}}"/>
                                        <button type="submit" class="btn btn-info text-center"><img class="card-img-top" title="Actualizar precio o disponibilidad" src="{{asset('/imagen/iconos/guardar.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></button>
                                    </td>
                                </form>
                                <td class="text-center">{{$orden->Producto->disponibilidad}}</td>   
                                <form action="{{route('ordene.eliminarorden',$orden->id)}}" method="POST" class="formEliminar">
                                    @csrf
                                    @method('DELETE') 
                                    <td class="text-center">
                                        <input title="Eliminar Producto" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
                                    </td> 
                                </form>                             
                                                                
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <label class="form-label">Nombre del Cliente</label>
                    <input id="nombre_cliente" disabled name="nombre_cliente" type="text" class="form-control" tabindex="1" value="{{$solicitud->nombre_cliente}}">
                    <label class="form-label">Telefono</label>
                    <input id="telefono" disabled name="telefono" type="number" class="form-control" tabindex="1" value="{{$solicitud->telefono}}">
                    <label class="form-label">Correo</label>
                    <input id="correo" disabled name="correo" type="text" class="form-control" tabindex="1" value="{{$solicitud->correo}}">
                    <label class="form-label">Direccion</label>
                    <input id="direccion" disabled name="direccion" type="text" class="form-control" tabindex="1" value="{{$solicitud->direccion}}">
                    
                    <br>
                </div>
                </div>                        
                <a href="{{route('orden.index')}}" class="btn btn-secondary" tabindex="3">Regresar</a>           
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    <script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('js/dataTables.bootstrap5.min.js')}}"></script>
    <script src="{{asset('js/dataTables.responsive.min.js')}} "></script>
    <script src="{{asset('js/responsive.bootstrap5.min.js')}}"></script>
    <script src="{{asset('js/configuracion.js')}}"></script>
    @if(session('disponible') == 'ok')
        <script type="application/javascript">
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection