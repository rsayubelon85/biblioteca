@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>ASIGNAR TARIFA</h2>
                <form action="{{route('tarifarios.store')}}" method="POST">
                    @csrf
                    <div class="mb-5">
                        <label class="form-label">Tarifa</label>
                        <div class="col-auto">
                            <select name="tarifa" id="tarifa" class="form-control selectpicker" title="Seleccionar Tarifa">
                                @foreach ($tarifas as $tarifa)
                                    <option value="{{$tarifa->id}}">{{$tarifa->nombre}}</option>
                                @endforeach
                            </select>  
                        </div>                        
                        <table class="table table-primary table-striped mt-4" id="tarifarios">
                            <thead>
                                <tr>
                                    <th scope="col">Plan</th>
                                    <th scope="col">Moneda Base</th>
                                    <th scope="col">Valor del Cambio</th>
                                    <th scope="col">Moneda Secundaria</th>                        
                                    <th scope="col">Escoger</th> 
                                </tr>            
                            </thead>
                            <tbody>
                                @foreach ($planes as $plan)
                                <tr>
                                    <td>{{$plan->id}}</td>
                                    <td>{{$plan->MonedaPri->nombre}}</td>
                                    <td>{{$plan->valor_cambio}}</td>  
                                    <td>{{$plan->MonedaSec->nombre}}</td>      
                                    <td><input type="checkbox" id="plan[]" name="plan[]" value="{{$plan->id}}"/></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>                                                    
                        <br>                    
                    </div>                    
                    <a href="{{route('tarifarios.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    <script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('js/dataTables.bootstrap5.min.js')}}"></script>
    <script src="{{asset('js/dataTables.responsive.min.js')}} "></script>
    <script src="{{asset('js/responsive.bootstrap5.min.js')}}"></script>
    <script src="{{asset('js/configuracion.js')}}"></script>
    <script>
        $('#tarifarios').DataTable({
            responsive: true,
            autoWidth: false
        });
    </script>
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection