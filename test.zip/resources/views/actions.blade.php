@if (Session::get('TypeController') == 'Categoria')
    <form action="{{route('categorias.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="{{route('categorias.edit',$id)}}" ><img class="card-img-top" title="Editar Categoria" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Categoria" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>    
@endif
@if (Session::get('TypeController') == 'Moneda')
    <form action="{{route('monedas.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="{{route('monedas.edit',$id)}}" ><img class="card-img-top" title="Editar Moneda" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Moneda" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
@endif
@if (Session::get('TypeController') == 'Tarifa')
    <form action="{{route('tarifas.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="{{route('tarifas.edit',$id)}}" ><img class="card-img-top" title="Editar Tarifa" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Tarifa" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
@endif
@if (Session::get('TypeController') == 'Plan')
    <form action="{{route('plans.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="{{route('plans.edit',$id)}}" ><img class="card-img-top" title="Editar Plan" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Plan" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
@endif
@if (Session::get('TypeController') == 'Tarifario')
    <form action="{{route('tarifarios.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col">
                <a href="{{route('tarifarios.edit',$id)}}" ><img class="card-img-top" title="Editar Tarifario" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Tarifario" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
@endif
@if (Session::get('TypeController') == 'Producto')
    <form action="{{route('ordene.destroy',$id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col" style="width: 20px">
                <a href="{{route('productos.edit',$id)}}" ><img class="card-img-top" title="Editar Producto" src="{{asset('/imagen/iconos/pencil-squarenaranja.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col" style="width: 20px">
                <a href="{{route('product.editpd',$id)}}" ><img class="card-img-top" title="Actualizar precio o disponibilidad" src="{{asset('/imagen/iconos/editimg2.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>
            <div class="col" style="width: 20px">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Producto" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>  
@endif
@if (Session::get('TypeController') == 'Catalogo')
    
    <input type="checkbox" id="chbox" onclick="window.location='{{route('catalogo.select',$id)}}'" style="transform: scale(2.0)"/>
 
@endif

@if (Session::get('TypeController') == 'Ordene')

    <form action="{{route('ordene.destroy',$solicitude_id)}}" method="POST" class="formEliminar">
        <div class="row  align-items-start">
            <div class="col" style="width: 10px">
                <input type="checkbox" id="chbox" title="Confirmar orden" onclick="window.location='{{route('ordene.confirmar',$solicitude_id)}}'" style="transform: scale(2.0)"/>
            </div>
            <div class="col" style="width: 10px">
                <a href="{{route('ordene.show',$solicitude_id)}}" ><img class="card-img-top" title="Mostrar Orden" src="{{asset('/imagen/iconos/show_icon.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
            </div>      
            <div class="col" style="width: 10px">
                @if($ordene_id == 0)
                    <a ><img class="card-img-top" title="Editar Orden Inabilitada" src="/imagen/iconos/pencil-squaregris.png" alt="Card image" style="width:30px" style="display: inline-block"></a>            
                @else
                    <a href="{{route('ordene.edit',$solicitude_id)}}" ><img class="card-img-top" title="Editar Orden " src="/imagen/iconos/pencil-squarenaranja.png" alt="Card image" style="width:30px" style="display: inline-block"></a>
                @endif                
            </div>
            <div class="col" style="width: 10px">
                @csrf
                @method('DELETE')    
                <input title="Eliminar Orden" src="{{asset('/imagen/iconos/trashrojo.png')}}"  type="image" style="width: 30px"/>
            </div>
        </div>
    </form>
@endif

@if (Session::get('TypeController') == 'OrdeneConfirmada')

    <div class="col" style="width: 10px">
        <a href="{{route('ordene.show',$solicitude_id)}}" ><img class="card-img-top" title="Mostrar Orden" src="{{asset('/imagen/iconos/show_icon.png')}}" alt="Card image" style="width:30px" style="display: inline-block"></a>
    </div>

@endif

<script>
$(document).ready(function () {
    $(".formEliminar").submit(function(e){
        e.preventDefault(); 
        
        Swal.fire({
            title: 'Está usted seguro?',
            text: "No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, borrarlo!',
            cancelButtonText: 'Cancelar'
            }).then((result) => {
            if (result.isConfirmed) {
                
                this.submit();
            }
        })
    });
})    
</script>


