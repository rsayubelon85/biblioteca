@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>CREAR TARIFA</h2>
                <form action="{{route('tarifas.store')}}" method="POST">
                    @csrf
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="{{old('nombre')}}">
                        @error('nombre')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Fecha Inicial</label>
                        <input id="fecha_inicial" name="fecha_inicial" type="date" class="form-control" tabindex="1" value="{{old('fecha_inicial')}}">
                        @error('fecha_inicial')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Fecha Final</label>
                        <input id="fecha_final" name="fecha_final" type="date" class="form-control" tabindex="1" value="{{old('fecha_final')}}">
                        @error('fecha_inicial')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Porciento de descuento o aumento al precio del producto (%)</label>
                        <input id="variacion_precio" name="variacion_precio" type="number" step="0.01" class="form-control" tabindex="1" value="{{old('fecha_final',0)}}">
                        @error('precio')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <table class="table table-primary table-striped mt-4">
                            <thead>
                                <tr>
                                    <th scope="col">Lunes</th>
                                    <th scope="col">Martes</th>
                                    <th scope="col">Miércoles</th>
                                    <th scope="col">Jueves</th>
                                    <th scope="col">Viernes</th>
                                    <th scope="col">Sábado</th>
                                    <th scope="col">Domingo</th>
                                </tr>            
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input name="lunes" type="checkbox"></td>
                                    <td><input name="martes" type="checkbox"></td>
                                    <td><input name="miercoles" type="checkbox"></td>
                                    <td><input name="jueves" type="checkbox"></td>
                                    <td><input name="viernes" type="checkbox"></td>
                                    <td><input name="sabado" type="checkbox"></td>
                                    <td><input name="domingo" type="checkbox"></td>                                                          
                                </tr>                        
                            </tbody>
                        </table>                                                    
                        <br>                    
                    </div>
                    
                    <a href="{{route('tarifas.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection