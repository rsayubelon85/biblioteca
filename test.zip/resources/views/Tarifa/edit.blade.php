@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR TARIFA</h2>
                <form action="{{route('tarifas.update',$tarifa)}}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="{{old('nombre',$tarifa->nombre)}}">
                        @error('nombre')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Fecha Inicial</label>
                        <input id="fecha_inicial" name="fecha_inicial" type="date" class="form-control" tabindex="1" value="{{old('fecha_inicial',$tarifa->fecha_inicial)}}">
                        @error('fecha_inicial')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Fecha Final</label>
                        <input id="fecha_final" name="fecha_final" type="date" class="form-control" tabindex="1" value="{{old('fecha_final',$tarifa->fecha_final)}}">
                        @error('fecha_inicial')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Porciento de descuento o aumento al precio del producto (%)</label>
                        <input id="variacion_precio" name="variacion_precio" type="number" step="0.01" class="form-control" tabindex="1" value="{{old('fecha_final',$tarifa->variacion_precio)}}">
                        @error('precio')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <table class="table table-primary table-striped mt-4">
                            <thead>
                                <tr>
                                    <th scope="col">Lunes</th>
                                    <th scope="col">Martes</th>
                                    <th scope="col">Miércoles</th>
                                    <th scope="col">Jueves</th>
                                    <th scope="col">Viernes</th>
                                    <th scope="col">Sábado</th>
                                    <th scope="col">Domingo</th>
                                </tr>            
                            </thead>
                            <tbody>
                                <tr>
                                    @if (($tarifa->lunes))
                                        <td><input name="lunes" type="checkbox" checked></td>
                                    @else
                                        <td><input name="lunes" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->martes))
                                        <td><input name="martes" type="checkbox" checked></td>
                                    @else
                                        <td><input name="martes" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->miercoles))
                                        <td><input name="miercoles" type="checkbox" checked></td>
                                    @else
                                        <td><input name="miercoles" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->jueves))
                                        <td><input name="jueves" type="checkbox" checked></td>
                                    @else
                                        <td><input name="jueves" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->viernes))
                                        <td><input name="viernes" type="checkbox" checked></td>
                                    @else
                                        <td><input name="viernes" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->sabado))
                                        <td><input name="sabado" type="checkbox" checked></td>
                                    @else
                                        <td><input name="sabado" type="checkbox"></td>
                                    @endif
                                    @if (($tarifa->domingo))
                                        <td><input name="domingo" type="checkbox" checked></td>
                                    @else
                                        <td><input name="domingo" type="checkbox"></td>
                                    @endif                                                      
                                </tr>                        
                            </tbody>
                        </table>                                                    
                        <br>                    
                    </div>
                    
                    <a href="{{route('tarifas.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection