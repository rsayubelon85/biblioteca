@extends('layouts.plantilla')

@section('contenido')
    <h2>CREAR PLAN TARIFARIO</h2>
    <form action="{{route('plans.store')}}" method="POST">
        @csrf
        <div class="form-row align-items-center">
            <div class="col-auto">
                <label class="sr-only" for="inputmoneda">Moneda Base: {{$moneda_base}}</label>                                            
            </div>
            <div class="col-auto">
                <input id="valor_tarifa" name="valor_cambio" type="number" step="0.01" class="form-control" placeholder="Valor de Cambio" value="{{old('valor_cambio')}}">     
            </div>
            <div class="col-auto">
                <select name="moneda_select[]" id="moneda_select" class="form-control selectpicker" title="Seleccionar Moneda">
                    @foreach ($monedas_secundarias as $moneda_sec)
                        <option value="{{$moneda_sec->id}}">{{$moneda_sec->nombre}}</option>
                    @endforeach
                </select>  
            </div>                                    
        </div>
        <a href="{{route('plans.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>    
@endsection
@section('js')
@if(session('eliminar') == 'ok')
    <script>
        var type = "{{ Session::get('type') }}";
        var title = "{{ Session::get('title') }}";
        var message = "{{ Session::get('message') }}";
        Swal.fire(
                title,
                message,
                type
                )
    </script>
@endif
@endsection
