@extends('layouts.plantilla')

@section('contenido')
    <h2>EDITAR MONEDA</h2>
    <form action="{{route('monedas.update',$moneda)}}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="" class="form-label">Nombre</label>
            <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="{{old('nombre',$moneda->nombre)}}">
            @error('nombre')
                <br>
                <small>*{{$message}}</small>
                <br>
            @enderror
        </div>
        <a href="{{route('monedas.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>    
@endsection
@section('js')
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection