@extends('layouts.plantilla')

@section('contenido')
<div class="container">
    <div class="row justify-content-md-center">
    <div class="ml-2 col-sm-4">
    <div id="msg"></div>

    </div>
    </div>
</div>
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR PRECIO O DISPONIBILIDAD DEL PRODUCTO</h2>
                <form action="{{route('products.updatepd',$nombreProducto)}}" method="POST" id="image-form">
                    @csrf
                    @method('put')
                    <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" disabled tabindex="1" value="{{old('nombreProducto',$nombreProducto)}}">
                        @error('nombre')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                    <label class="form-label">Precio</label>
                    <input id="precio" name="precio" type="number" step="0.01" class="form-control" tabindex="1" value="{{old('precio',$precio)}}">
                    @error('precio')
                        <br>
                        <small>*{{$message}}</small>
                        <br>
                    @enderror
                    <label class="form-label">Disponibilidad</label>
                    <input id="disponibilidad" name="disponibilidad" type="number" class="form-control" tabindex="1" value="{{old('disponibilidad',$disponibilidad)}}">
                    @error('disponibilidad')
                        <br>
                        <small>*{{$message}}</small>
                        <br>
                    @enderror
                    
                    <a href="{{route('productos.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>           
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection