@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>EDITAR PRODUCTO</h2>
                <form action="{{route('productos.update',$producto)}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="{{old('nombre',$producto->nombre)}}">
                        @error('nombre')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Disponibilidad</label>
                        <input id="disponibilidad" name="disponibilidad" type="number" class="form-control" tabindex="1" value="{{old('disponibilidad',$producto->disponibilidad)}}">
                        @error('disponibilidad')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Precio</label>
                        <input id="precio" name="precio" type="number" step="0.01" class="form-control" tabindex="1" value="{{old('precio',$producto->precio)}}">
                        @error('precio')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Seleccionar Categoría</label><br>
                        <select name="categorias[]" id="categorias" class="form-control selectpicker"  data-style="btn-primary" title="Seleccionar Categorias">
                            <option value="{{$producto->categoria->id}}">{{$producto->categoria->nombre}}</option>
                            @foreach ($categorias as $categoria)
                                <option value="{{$categoria->id}}">{{$categoria->nombre}}</option>
                            @endforeach
                        </select>    
                        <br>
                        <label class="form-label">Descripción</label>
                        <textarea id="descripcion" name="descripcion" rows="5" type="text" class="form-control" tabindex="1" >{{old('descripcion',$producto->descripcion)}}</textarea>
                        @error('descripcion')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <div class="form-group">
                            <input type="file" name="imagen" class="imagen" hidden>
                            <div class="input-group my-3">
                                <input type="text" class="form-control" disabled placeholder="Cargar imagen" id="imagen">
                                <div class="input-group-append">
                                    <button type="button" class="browse btn btn-primary">Browse...</button>
                                </div>
                            </div>
                            @error('imagen')
                                <small>*{{$message}}</small>
                                <br>
                            @enderror
                        </div>
                        <div class="form-group">
                            <img src="{{asset('/imagen/'.$producto->imagen)}}" id="preview" class="img-thumbnail">
                        </div>
                        <br>
                    </div>
                    
                    <a href="{{route('productos.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
@endsection
@section('js')
    <script>
        $(document).on("click", ".browse", function() {
            var file = $(this).parent().parent().parent().find(".imagen");
            file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#imagen").val(fileName);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                // get loaded data and render thumbnail.
                document.getElementById("preview").src = e.target.result;
            };
            // read the image file as a data URL.
            reader.readAsDataURL(this.files[0]);

            /*$("#image-form").on("submit", function() {
                $("#msg").html('<div class="alert alert-info"><i class="fa fa-spin fa-spinner"></i> Espere por favor...!</div>');
                $.ajax({
                    type: "PUT",
                    url: "{{url('productos/{producto}/update')}}",
                    data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    contentType: false, // The content type used when sending data to the server.
                    cache: false, // To unable request pages to be cached
                    processData: false, // To send DOMDocument or non processed data file it is set to false
                    success: function(data) {
                        if (data == 1 || parseInt(data) == 1) {
                            $("#msg").html(
                                '<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Datos actualizados con éxito.</div>'
                            );
                        } else {
                            $("#msg").html(
                                '<div class="alert alert-info"><i class="fa fa-exclamation-triangle"></i> La extensión no es buena, solo prueba con <strong>GIF, JPG, PNG, JPEG</strong>.</div>'
                            );
                        }
                    },
                    error: function(data) {
                        $("#msg").html(
                            '<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Hay algo mal..</div>'
                        );
                    }
                });
            });*/
        });    
    </script>
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection