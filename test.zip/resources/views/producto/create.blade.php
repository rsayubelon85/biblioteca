@extends('layouts.plantilla')

@section('contenido')
    <div class="py12">
        <div class="max-w-71 mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-x1 sm:rounded-lg">
                <h2>CREAR PRODUCTO</h2>
                <form action="{{route('productos.store')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-5">
                        <label class="form-label">Nombre</label>
                        <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" value="{{old('nombre')}}">
                        @error('nombre')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Disponibilidad</label>
                        <input id="disponibilidad" name="disponibilidad" type="number" class="form-control" tabindex="1" value="{{old('disponibilidad')}}">
                        @error('disponibilidad')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Precio</label>
                        <input id="precio" name="precio" type="number" step="0.01" class="form-control" tabindex="1" value="{{old('precio')}}">
                        @error('precio')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror
                        <label class="form-label">Seleccionar Categoria</label><br>
                        <select name="categorias[]" id="categorias" class="form-control selectpicker" data-style="btn-primary" title="Seleccionar Categorias">
                            @foreach ($categorias as $categoria)
                                <option value="{{$categoria->id}}">{{$categoria->nombre}}</option>
                            @endforeach
                        </select>    
                        <br>
                        <label class="form-label">Descripción</label>
                        <textarea id="descripcion" name="descripcion" rows="5" type="text" class="form-control" tabindex="1" value="{{old('descripcion')}}"></textarea>
                        @error('descripcion')
                            <br>
                            <small>*{{$message}}</small>
                            <br>
                        @enderror 
                        <br>
                        <div class="form-group">
                            <input type="file" name="imagen" class="imagen" hidden>
                            <div class="input-group my-3">
                                <input type="text" class="form-control" disabled placeholder="Cargar imagen" id="imagen">
                                <div class="input-group-append">
                                    <button type="button" class="browse btn btn-primary">Browse...</button>
                                </div>
                            </div>
                            @error('imagen')
                                <small>*{{$message}}</small>
                                <br>
                            @enderror
                        </div>
                        <div class="form-group">
                            <img id="preview" class="img-thumbnail">
                        </div>
                        <br>
                    </div>
                    </div>
                    
                    <a href="{{route('productos.index')}}" class="btn btn-secondary" tabindex="3">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>            
            </div>
        </div>
    </div>
    
@endsection
@section('js')
<script>
        $(document).on("click", ".browse", function() {
            var file = $(this).parent().parent().parent().find(".imagen");
            file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#imagen").val(fileName);
            
            var reader = new FileReader();
            reader.onload = function(e) {
                // get loaded data and render thumbnail.
                document.getElementById("preview").src = e.target.result;
            };
            // read the image file as a data URL.
            reader.readAsDataURL(this.files[0]);
        });    
</script>
    @if(session('eliminar') == 'ok')
        <script>
            var type = "{{ Session::get('type') }}";
            var title = "{{ Session::get('title') }}";
            var message = "{{ Session::get('message') }}";
            Swal.fire(
                    title,
                    message,
                    type
                    )
        </script>
    @endif
@endsection