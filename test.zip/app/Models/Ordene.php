<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ordene extends Model
{
    use HasFactory;
    protected $fillable = ['solicitude_id','producto_id','cantidad'];

    //Relacion uno a muchos una orden tiene solo una solicitud
    public function Solicitud(){
        return $this->belongsTo('\App\Models\Solicitude');
    }

    //Relacion uno a muchos una orden tiene solo un producto
    public function Producto(){
        return $this->belongsTo('\App\Models\Producto');
    }  
}
