<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tarifario extends Model
{
    use HasFactory;
    protected $fillable = ['tarifa_id','plan_id'];

    //Relacion uno a muchos un tarifario tiene solo un plan
    public function Plan(){
        return $this->belongsTo('\App\Models\Plan');
    }

    //Relacion uno a muchos un tarifario tiene solo una tarifa
    public function Tarifa(){
        return $this->belongsTo('\App\Models\Tarifa');
    }
}
