<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;
    protected $fillable = ['nombre','slug'];

    public function getRouteKeyName(){
        return 'slug';
    }

    //Relacion uno a muchos una categoria puede estar en varios productos
    public function Productos(){
        return $this->hasMany('\App\Models\Producto');
    }
}
