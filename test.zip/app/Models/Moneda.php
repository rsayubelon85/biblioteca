<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Moneda extends Model
{
    use HasFactory;

    protected $fillable = ['nombre','moneda_base'];

    //Relacion uno a muchos una moneda puede estar en varios planes
    public function PlanesPri(){
        return $this->hasMany('\App\Models\Plan','moneda_primaria_id','id');
    }

    //Relacion uno a muchos una moneda puede estar en varios planes
    public function PlanesSec(){
        return $this->hasMany('\App\Models\Plan','moneda_secundaria_id','id');
    }

    //Relacion uno a muchos una moneda puede estar en varios planes
    public function Solicitudes(){
        return $this->hasMany('\App\Models\Solicitude');
    }
}
