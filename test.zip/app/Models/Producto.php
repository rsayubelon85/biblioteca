<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    use HasFactory;
    protected $fillable = ['nombre','slug','precio','disponibilidad','imagen','descripcion','categoria_id'];

    public function getRouteKeyName(){

        return 'slug';
    }

    //Relacion uno a muchos un producto tiene solo una categoria
    public function Categoria(){
        return $this->belongsTo('\App\Models\Categoria');
    }

    //Relacion uno a muchos un producto puede estar en varias ordenes
    public function Ordenes(){
        return $this->hasMany('\App\Models\Ordene');
    }
}
