<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    use HasFactory;
    protected $fillable = ['moneda_primaria_id','moneda_secundaria_id','valor_cambio'];

    //Relacion uno a muchos un plan tiene solo una moneda base
    public function MonedaPri(){
        return $this->belongsTo('\App\Models\Moneda','moneda_primaria_id','id');
    }

    //Relacion uno a muchos un plan tiene solo una moneda secundaria
    public function MonedaSec(){
        return $this->belongsTo('\App\Models\Moneda','moneda_secundaria_id','id');
    }

    //Relacion uno a muchos un plan puede estar en varios tarifarios
    public function Tarifarios(){
        return $this->hasMany('\App\Models\Tarifario');
    }
}
