<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Solicitude extends Model
{
    use HasFactory;
    protected $fillable = ['numero_solicitud','nombre_cliente','telefono','correo','direccion','confirmado','tarifa_id','moneda_id'];

    //Relacion uno a muchos una solicitud puede estar en varias ordenes
    public function Ordenes(){
        return $this->hasMany('\App\Models\Ordene');
    }

    //Relacion uno a muchos una salicitud tiene solo una tarifa
    public function Tarifa(){
        return $this->belongsTo('\App\Models\Tarifa');
    }

    //Relacion uno a muchos una salicitud tiene solo un solo tipo de moneda
    public function Moneda(){
        return $this->belongsTo('\App\Models\Moneda');
    }
}
