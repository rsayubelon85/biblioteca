<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tarifa extends Model
{
    use HasFactory;

    protected $fillable = ['nombre','fecha_inicial','fecha_final','lunes','martes','miercoles','jueves','viernes','sabado','domingo','activado','variacion_precio'];

    //Relacion uno a muchos una tarifa puede estar en varios tarifarios
    public function Tarifarios(){
        return $this->hasMany('\App\Models\Tarifario');
    }

    //Relacion uno a muchos una tarifa puede estar en varias solicitudes
    public function Solicitudes(){
        return $this->hasMany('\App\Models\Solicitude');
    }
}
