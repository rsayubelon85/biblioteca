<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RulesProductos extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'nombre' => 'required|max:50|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'precio' => 'required|numeric',
            'disponibilidad' => 'required|integer',
            'imagen' => 'required|image|mimes:jpg,jpeg,png,svg|max:1024'
        ];
        /*
        //email,max,min,digits,numeric,between:9,11,regex:/(01)[0-9]{9},unique:posts,Rule::unique('posts', 'title')->ignore($this->post)
                                                                                      //integer|not_in:0,regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+) 

        $table->double('precio');
            $table->integer('disponibilidad');
            $table->string('imagen');
            $table->text('descripcion')->nullable();
        */
    }
}
