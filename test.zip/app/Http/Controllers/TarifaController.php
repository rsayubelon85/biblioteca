<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tarifa;
use App\Models\Moneda;
use App\Http\Requests\RulesTarifa;
use App\Models\Solicitude;
use App\Models\Tarifario;
use Illuminate\Support\Arr;
use PHPUnit\Framework\Constraint\ArrayHasKey;
use Illuminate\Support\Facades\Session;

class TarifaController extends Controller
{
    public function tarifas()
    {
        Session::put('TypeController', 'Tarifa');
        
        $tarifas = Tarifa::all();
        foreach ($tarifas as $tarifa) {
            $tarifa->lunes?$tarifa->lunes = 'Si':$tarifa->lunes = 'No';
            $tarifa->martes?$tarifa->martes = 'Si':$tarifa->martes = 'No';
            $tarifa->miercoles?$tarifa->miercoles = 'Si':$tarifa->miercoles = 'No';
            $tarifa->jueves?$tarifa->jueves = 'Si':$tarifa->jueves = 'No';
            $tarifa->viernes?$tarifa->viernes = 'Si':$tarifa->viernes = 'No';
            $tarifa->sabado?$tarifa->sabado = 'Si':$tarifa->sabado = 'No';
            $tarifa->domingo?$tarifa->domingo = 'Si':$tarifa->domingo = 'No';
        }

        return datatables()->collection($tarifas)
                           ->addColumn('action','actions')
                           ->toJson();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        Session::put('eliminar', '');     
        return view('tarifa.index');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Moneda::where('moneda_base',true)->get()->count() == 0 || Moneda::all()->count() == 0){//No existe una moneda base
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'exito',
                'title'    => 'Disponibilidad!',
                'message'  => 'No existen monedas creadas y debe de escoger una Moneda Base antes de crear la tarifa',
                'NS'       => ''
            );
            return redirect('/tarifas')->with($message);         
        }
       
        return view('tarifa.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RulesTarifa $request)
    {        
        if($request->fecha_inicial > $request->fecha_final){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Rango de fecha!',
                'message'  => 'La fecha inicial debe ser menor que la fecha final',
                'NS'       => ''
            );
            return redirect('/tarifas/create')->with($message); 
        }
        $tarifas = Tarifa::all();
        $tarifa = new Tarifa();           
        
        ($request->lunes == "on")?$tarifa->lunes = 1:$tarifa->lunes = 0;
        ($request->martes == "on")?$tarifa->martes = 1:$tarifa->martes = 0;
        ($request->miercoles == "on")?$tarifa->miercoles = 1:$tarifa->miercoles = 0;
        ($request->jueves == "on")?$tarifa->jueves = 1:$tarifa->jueves = 0;
        ($request->viernes == "on")?$tarifa->viernes = 1:$tarifa->viernes = 0;
        ($request->sabado == "on")?$tarifa->sabado = 1:$tarifa->sabado = 0;
        ($request->domingo == "on")?$tarifa->domingo = 1:$tarifa->domingo = 0;

        if(!$tarifa->lunes && !$tarifa->martes && !$tarifa->miercoles && !$tarifa->jueves && !$tarifa->viernes && !$tarifa->sabado && !$tarifa->domingo)
        {
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Selección de dias',
                'message'  => 'Debe al menos seleccionar un dia',
                'NS'       => ''
            );
            return redirect('/tarifas/create')->with($message);           
        }

        //Comparaciones de fecha para saber si la tarifa que se insertara esta en el mismo rango de las tarifas que estan presentes
        //1 Que exista alguna tarifa con fecha inicial en la BD que este en el rango de fecha entrada por el usuario
        //2 Que exista alguna tarifa con fecha final en la BD que este en el rango de fecha entrada por el usuario
        //3 Que exista alguna tarifa donde el rango de fecha entrado por el usuario incluya al rango de fecha de esta tarifa
        
        if( $tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final])->count() > 0 ||
            $tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final])->count() > 0 ||
            ($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final)->count() > 0))
            {
                $tarifasselect = array();
                if($tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final])->count() > 0)
                {
                    foreach($tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final]) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    }
                }
                if($tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final])->count() > 0)
                {
                    foreach($tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final]) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    }
                }
                if($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final)->count() > 0)
                {
                    foreach($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    } 
                }
                    

                //SI pasa es que los rangos de fecha coinciden en algun momento
                //Paso a comprobar los dias 
                foreach($tarifasselect as $tarifasel){
                    //return $tarifasel;
                    if( ($tarifasel['lunes'] == 1 && $tarifa->lunes == 1) || 
                        ($tarifasel['martes'] == 1 && $tarifa->martes == 1) || 
                        ($tarifasel['miercoles'] == 1 && $tarifa->miercoles == 1) ||
                        ($tarifasel['jueves'] == 1 && $tarifa->jueves == 1) || 
                        ($tarifasel['viernes'] == 1 && $tarifa->viernes == 1) || 
                        ($tarifasel['sabado'] == 1 && $tarifa->sabado == 1) ||
                        ($tarifasel['domingo'] == 1 && $tarifa->domingo == 1))
                    {                           
                        //Si existe algun dia que coincide entonces no se puede insertar la tarifa
                        $message = array(
                            'eliminar' => 'ok',
                            'type'     => 'error',
                            'title'    => 'Rango de fecha!',
                            'message'  => 'El rango de fecha insertado coincide con el rango de fecha de una tarifa existente, estos deben de ser diferentes',
                            'NS'       => ''
                        );
                        return redirect('/tarifas/create')->with($message);
                    }
                }              

            }
        $tarifa->nombre = $request->nombre;
        $tarifa->fecha_inicial = $request->fecha_inicial;
        $tarifa->fecha_final = $request->fecha_final;        
        $tarifa->variacion_precio = $request->variacion_precio;
        $tarifa->save();

        return redirect('/tarifas');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tarifa = Tarifa::find($id);
        return  view('tarifa.edit',compact('tarifa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RulesTarifa $request, $id)
    {
        if($request->fecha_inicial > $request->fecha_final){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Rango de fecha!',
                'message'  => 'La fecha inicial debe ser menor que la fecha final',
                'NS'       => ''
            );
            return redirect('/tarifas/create')->with($message); 
        }
        $tarifas = Tarifa::all();
        $tarifas = $tarifas->where('id','<>',$id);
        $tarifa = Tarifa::find($id);           
        
        ($request->lunes == "on")?$tarifa->lunes = 1:$tarifa->lunes = 0;
        ($request->martes == "on")?$tarifa->martes = 1:$tarifa->martes = 0;
        ($request->miercoles == "on")?$tarifa->miercoles = 1:$tarifa->miercoles = 0;
        ($request->jueves == "on")?$tarifa->jueves = 1:$tarifa->jueves = 0;
        ($request->viernes == "on")?$tarifa->viernes = 1:$tarifa->viernes = 0;
        ($request->sabado == "on")?$tarifa->sabado = 1:$tarifa->sabado = 0;
        ($request->domingo == "on")?$tarifa->domingo = 1:$tarifa->domingo = 0;

        if(!$tarifa->lunes && !$tarifa->martes && !$tarifa->miercoles && !$tarifa->jueves && !$tarifa->viernes && !$tarifa->sabado && !$tarifa->domingo)
        {
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Selección de dias',
                'message'  => 'Debe al menos seleccionar un dia',
                'NS'       => ''
            );
            return redirect('/tarifas/create')->with($message);           
        }

        //Comparaciones de fecha para saber si la tarifa que se insertara esta en el mismo rango de las tarifas que estan presentes
        //1 Que exista alguna tarifa con fecha inicial en la BD que este en el rango de fecha entrada por el usuario
        //2 Que exista alguna tarifa con fecha final en la BD que este en el rango de fecha entrada por el usuario
        //3 Que exista alguna tarifa donde el rango de fecha entrado por el usuario incluya al rango de fecha de esta tarifa
        
        if( $tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final])->count() > 0 ||
            $tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final])->count() > 0 ||
            ($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final)->count() > 0))
            {
                $tarifasselect = array();
                if($tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final])->count() > 0)
                {
                    foreach($tarifas->whereBetween('fecha_inicial',[$request->fecha_inicial,$request->fecha_final]) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    }
                }
                if($tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final])->count() > 0)
                {
                    foreach($tarifas->whereBetween('fecha_final',[$request->fecha_inicial,$request->fecha_final]) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    }
                }
                if($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final)->count() > 0)
                {
                    foreach($tarifas->where('fecha_inicial','<',$request->fecha_inicial)->where('fecha_final','>',$request->fecha_final) as $tarifaT){
                        array_push($tarifasselect,$tarifaT);
                    } 
                }
    

                //SI pasa es que los rangos de fecha coinciden en algun momento
                //Paso a comprobar los dias 
                foreach($tarifasselect[0] as $tarifasel){
                    if( ($tarifasel['lunes'] == 1 && $tarifa->lunes == 1) || 
                        ($tarifasel['martes'] == 1 && $tarifa->martes == 1) || 
                        ($tarifasel['miercoles'] == 1 && $tarifa->miercoles == 1) ||
                        ($tarifasel['jueves'] == 1 && $tarifa->jueves == 1) || 
                        ($tarifasel['viernes'] == 1 && $tarifa->viernes == 1) || 
                        ($tarifasel['sabado'] == 1 && $tarifa->sabado == 1) ||
                        ($tarifasel['domingo'] == 1 && $tarifa->domingo == 1))
                    {   
                        //Si existe algun dia que coincide entonces no se puede insertar la tarifa
                        $message = array(
                            'eliminar' => 'ok',
                            'type'     => 'error',
                            'title'    => 'Rango de fecha!',
                            'message'  => 'El rango de fecha insertado coincide con el rango de fecha de una tarifa existente, estos deben de ser diferentes',
                            'NS'       => ''
                        );
                        return redirect('/tarifas/create')->with($message);
                    }
                }              

            }
        $tarifa->nombre = $request->nombre;
        $tarifa->fecha_inicial = $request->fecha_inicial;
        $tarifa->fecha_final = $request->fecha_final;        
        $tarifa->variacion_precio = $request->variacion_precio;

        $tarifa->touch();

        return redirect('/tarifas');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(Tarifario::where('tarifa_id',$id)->get()->count() > 0)
        {
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Tarifa asignada!',
                'message'  => 'La tarifa no se puede eliminar porque está asignada a un Plan, debe dejar de asociarlo para poder eliminarla.',
                'NS'       => ''
            );
            return redirect('/tarifas')->with($message);
        }
        if(Solicitude::where('tarifa_id',$id)->get()->count() > 0)
        {
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Tarifa asignada!',
                'message'  => 'La tarifa no se puede eliminar porque está asignada a una orden ya registrada.',
                'NS'       => ''
            );
            return redirect('/tarifas')->with($message);
        }
        $tarifa = Tarifa::find($id);
        $tarifa->delete();

        return redirect('/tarifas');
    }
}
