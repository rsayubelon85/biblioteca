<?php

namespace App\Http\Controllers;

use App\Models\Ordene;
use App\Models\Solicitude;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Models\Tarifa;
use App\Models\Tarifario;
use App\Models\Producto;
use PhpParser\Node\Stmt\If_;

class OrdeneController extends Controller
{
    
    public function ordenes(){

        Session::put('TypeController', 'Ordene');

        $solicitudes = DB::table('solicitudes')                            
                            ->leftJoin('ordenes','ordenes.solicitude_id','=','solicitudes.id')
                            ->leftjoin('productos','productos.id','=','ordenes.producto_id')
                            ->leftjoin('tarifas','tarifas.id','=','solicitudes.tarifa_id')
                            ->leftjoin('monedas','monedas.id','solicitudes.moneda_id')
                            ->select(   'solicitudes.id as solicitude_id','solicitudes.numero_solicitud','productos.nombre as nombreProducto',
                                        'productos.precio as precioProducto','ordenes.id as ordene_id','ordenes.cantidad','solicitudes.nombre_cliente',
                                        'solicitudes.telefono','monedas.nombre as nombreMoneda','solicitudes.confirmado','solicitudes.updated_at')
                            ->where('solicitudes.confirmado',0)
                            ->get();
              
        $Array_solicitudes = collect();
        $orden_str = '';
        $ordencont = '';
        $numero_solicitud = '';
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>=',now())->first();
        $totalGeneral = 0;
        $totalGeneralStr = '0';
        
        foreach($solicitudes as $solicitud)
        {            
            if($numero_solicitud != $solicitud->numero_solicitud){
                
                if($orden_str != ''){                     
                    $solicitud_compuesta['ordenes'] = Str::replaceLast(',', '', $ordencont);                       
                     
                    $Array_solicitudes->push($solicitud_compuesta);
                    
                    $orden_str = '';
                    $ordencont = '';
                    $totalGeneral = 0;
                }
                $solicitud_compuesta['solicitude_id'] = $solicitud->solicitude_id;
                $solicitud->ordene_id == null ? $solicitud_compuesta['ordene_id'] = 0 : $solicitud_compuesta['ordene_id'] = $solicitud->ordene_id;
                $solicitud_compuesta['numero_solicitud'] = $solicitud->numero_solicitud;
                $solicitud_compuesta['nombre_cliente'] = $solicitud->nombre_cliente;
                $solicitud_compuesta['telefono'] = $solicitud->telefono;
                $solicitud_compuesta['fecha'] = $solicitud->updated_at;
                $solicitud_compuesta['confirmado'] = $solicitud->confirmado;
                $numero_solicitud = $solicitud->numero_solicitud; 
                
                $totalGeneral == 0 ? $totalGeneral = $solicitud->precioProducto * $solicitud->cantidad : $totalGeneral += $solicitud->precioProducto * $solicitud->cantidad; 
                
            }
            else
                $totalGeneral += $solicitud->precioProducto * $solicitud->cantidad;
            
            
            if ($solicitud->cantidad != null) {

                $totalGeneralStr = $totalGeneral;
                if ($tarifa_actual == null) { 
                    
                    $solicitud->nombreMoneda == null ? $totalGeneralStr = $totalGeneralStr.$totalGeneral : $totalGeneralStr = $totalGeneral.' '.$solicitud->nombreMoneda;  
                    
                } else {
                    $totalGeneralStr = $solicitud->nombreMoneda.' $'.$totalGeneral;
                } 

                $solicitud_compuesta['totalGeneral'] = $totalGeneralStr;
                $orden_str = $solicitud->nombreProducto.' Pre: '.$solicitud->precioProducto.$solicitud->nombreMoneda.' Cant: '.$solicitud->cantidad;
            }
            else {
                $solicitud_compuesta['totalGeneral'] = '0';
                $orden_str = 'SIN ORDEN';
            }
            $ordencont = $ordencont.$orden_str.',';
        }
        
        if($solicitudes->count() == 0)
        {
            $solicitud_compuesta['solicitude_id'] = 0;
            $solicitud_compuesta['confirmado'] = 0;
        }
                
        $solicitud_compuesta['ordenes'] = Str::replaceLast(',', '', $ordencont);
        $Array_solicitudes->push($solicitud_compuesta);
        
        return  datatables()->collection($Array_solicitudes)
                ->addColumn('action','actions')
                ->toJson();

    }

    public function index(){  
        Session::put('eliminar', '');
        Session::put('disponible', '');

        //Buscar solicitudes y ordenes sin nombre del cliente y que sean de ayer
        $solicitudes = Solicitude::where('nombre_cliente',null)
                                   ->where('telefono',null)
                                   ->where('correo',null)
                                   ->whereRaw('updated_at < DATE_ADD(NOW(), INTERVAL -1 DAY)')
                                   ->get();
        
        
        //-date_add('d',-1);Averiguar como restar un dia a la fecha actual
        //return $solicitudes;
        for ($i=0; $i < $solicitudes->count(); $i++) { 
            for ($j=0; $j < $solicitudes[$i]->Ordenes->count(); $j++) { 
                $orden_actual = $solicitudes[$i]->Ordenes[$j];
                if(now() > $orden_actual->updated_at)
                    $orden_actual->delete();
            }
            $solicitudes[$i]->delete();
        }
        return view('ordene.index');
    }

    public function confirmar_orden($solicitude_id){

        $solicitud = Solicitude::find($solicitude_id);
        //Se debe de revisar la disponibilidad de los productos en el sistema
        foreach ($solicitud->Ordenes as $orden) {
            $producto = Producto::find($orden->producto_id);
            if ($orden->cantidad > $producto->disponibilidad) {
                $message = array(
                    'disponibilidad' => 'ok',
                    'type'     => 'info',
                    'title'    => 'Disponibilidad!',
                    'message'  => 'No se confirma la orden porque el producto '.$producto->nombre.' no tiene la cantidad solicitada, debe ajustar la orden nuevamente.',
                    'NS'       => ''
                );
                return redirect('/ordene')->with($message);
            }
        }
        //Actualizo la cantidad disponible de los productos de esta solicitud
        foreach ($solicitud->Ordenes as $orden) {
            $producto = Producto::find($orden->producto_id);

            $producto->disponibilidad - $orden->cantidad < 0 ? $producto->disponibilidad = 0 : $producto->disponibilidad -= $orden->cantidad;

            $producto->touch();
        }
        $solicitud->confirmado = true;
        $solicitud->touch();  
        
        $message = array(
            'disponibilidad' => 'ok',
            'type'     => 'exito',
            'title'    => 'Enviado!',
            'message'  => 'Al confirmar esta orden, se le envió un correo de confirmación al cliente de la gestión sin dificultades de su orden.',
            'NS'       => ''
        );
        //$correo_destino = 'rsayubelon85@gmail.com';
        //Mail::to($correo_destino)->send(new DatosSolicitudMaillable());
        
        return redirect('/ordene')->with($message);   
    }

    public function Show_Ord($id_sol){

        $solicitud = Solicitude::find($id_sol);

        return view('ordene.show',compact('solicitud'));    
    }

    public function edit($solicitude_id){//$id es el id de la solicitud
        
        $solicitud = Solicitude::find($solicitude_id);    

        //Session::put('numero_solicitud', $solicitud->numero_solicitud);
        Session::put('eliminar', '');
        Session::put('disponible', '');
        Session::put('id_solicitud', $solicitud->id);
        $message = '';
        return view('ordene.edit',compact('solicitud','message'));  
    
    }

    public function destroy_Ord($id){

        $orden = Ordene::find($id);

        $solicitude_id = $orden->solicitude_id;
        
        //return $solicitude_id;
        $orden->delete();
                
        $solicitud = Solicitude::find($solicitude_id);

        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Producto!',
            'message'  => 'El producto ha sido eliminado correctamente',
            'NS'       => $solicitud->numero_solicitud
        ); 
        
        Session::put('eliminar','ok');
        Session::put('disponible','');
        Session::put('type','error');
        Session::put('title','Producto!');
        Session::put('message','El producto ha sido eliminado correctamente');
        
        return view('ordene.edit',compact('solicitud'));  

    }

    public function update_Cant(Request $request,$id){

        $orden = Ordene::find($id);        
        $numero_solicitud = Session::get('numero_solicitud');
        
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>=',now())->first();

        $orden->cantidad = $request["disponibilidad"];

        $solicitud = Solicitude::where('numero_solicitud',$numero_solicitud)->get()[0];

        
        if($orden->Producto->disponibilidad == 0 || $orden->cantidad > $orden->Producto->disponibilidad)
        { 
            Session::put('disponible', 'ok');
            Session::put('type', 'error');
            Session::put('title', 'Disponibilidad!');
            Session::put('message', 'El producto ya no tiene disponibilidad');
            return view('ordene.edit',compact('solicitud')); 
        }
        else{
            Session::put('disponible', '');
        } 
        $orden->touch();     

        return view('ordene.edit',compact('solicitud'));

    }

    public function productos_ordenes()
    {
        Session::put('TypeController', 'Ordene');

        $productos = DB::table('productos')
                                ->join('categorias','categorias.id','=','productos.categoria_id')
                                ->select('productos.id','productos.nombre as nombreProducto','imagen','precio','disponibilidad','descripcion','categorias.nombre as nombreCategoria')
                                ->where('disponibilidad','>',0)
                                ->where('productos.precio','>',0)
                                ->get();
        
        foreach ($productos as $producto) {
            if (!Str::contains($producto->imagen,'http')) {
                $producto->imagen = 'imagen/'.$producto->imagen;
            }
            $producto->id_sol = Session::get('id_solicitud');
        }        

        return  datatables()->collection($productos)
                            ->addColumn('action','actions')                            
                            ->toJson();
                            
    }  

    public function show_Productos($id){

        $id_sol = $id;

        Session::put('eliminar', '');
        Session::put('disponible', '');

        return view('ordene.addproductos',compact('id_sol'));
    }

    //-----Agregar producto a la orden
    public function add_solicitud_orden($id_prod,$id_sol){
        
        Session::put('eliminar', '');
        $producto = Producto::find($id_prod);

        $solicitud = Solicitude::find($id_sol);

        

        /*$message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Disponibilidad!',
            'message'  => 'El producto ya no tiene disponibilidad',
            'NS'       => $solicitud->numero_solicitud
        );*/ 

        $ordenes = Ordene::where('solicitude_id',$solicitud->id)->where('producto_id',$producto->id)->get(); //Es para saber si ya existe el producto asignado a esa orden
        
                
        if ($ordenes->count() == 0) {//No existe una orden con esta solicitud y este producto
            $orden = new Ordene();

            if($producto->disponibilidad == 0)
            {
                Session::put('disponible', 'ok');
                Session::put('type', 'error');
                Session::put('title', 'Disponibilidad!');
                Session::put('message', 'El producto ya no tiene disponibilidad');
                return view('ordene.addproductos',compact('id_sol'));
            } 
            $orden->solicitude_id = $solicitud->id;
            $orden->producto_id = $producto->id;
            $orden->cantidad = 1; 
        } else {            
            $orden = $ordenes[0];

            if ($orden->cantidad + 1 > $orden->Producto->disponibilidad) {
                Session::put('disponible', 'ok');
                Session::put('type', 'error');
                Session::put('title', 'Disponibilidad!');
                Session::put('message', 'El producto ya no tiene disponibilidad');
                return view('ordene.addproductos',compact('id_sol'));
            }
            else{
                Session::put('disponible', '');
            }
            $orden->cantidad = $orden->cantidad + 1;
        }

        $orden->touch();
        
        //return $id_sol;
        return view('ordene.addproductos',compact('id_sol'));

    }

    public function destroy($id_sol){//Debo eliminar la solicitud con todas sus ordenes
        
        $solicitud = Solicitude::find($id_sol);
        
        if($solicitud->Ordenes->count() > 0)
        {//existen ordenes asiganas a esta solicitud
            for ($i=0; $i < $solicitud->Ordenes->count(); $i++) { 
                $solicitud->Ordenes[$i]->delete();
            }
        }
        $solicitud->delete();

        $message = array(
            'eliminar' => 'ok',
            'disponible' => '',
            'type'     => 'exito',
            'title'    => 'Eliminado',
            'message'  => 'Su registro ha sido eliminado.'
        );
        
        return view('ordene.index')->with($message);
    
    }

    public function ordenes_Confirmadas()
    {
        Session::put('TypeController', 'OrdeneConfirmada');

        $solicitudes = DB::table('solicitudes')                            
                            ->leftJoin('ordenes','ordenes.solicitude_id','=','solicitudes.id')
                            ->leftjoin('productos','productos.id','=','ordenes.producto_id')
                            ->leftjoin('tarifas','tarifas.id','=','solicitudes.tarifa_id')
                            ->leftjoin('monedas','monedas.id','solicitudes.moneda_id')
                            ->select(   'solicitudes.id as solicitude_id','solicitudes.numero_solicitud','productos.nombre as nombreProducto',
                                        'productos.precio as precioProducto','ordenes.id as ordene_id','ordenes.cantidad','solicitudes.nombre_cliente',
                                        'solicitudes.telefono','monedas.nombre as nombreMoneda','solicitudes.confirmado','solicitudes.updated_at')
                            ->where('solicitudes.confirmado',1)
                            ->get();
              
        $Array_solicitudes = collect();
        $orden_str = '';
        $ordencont = '';
        $numero_solicitud = '';
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>=',now())->first();
        $totalGeneral = 0;
        $totalGeneralStr = '0';
        
        foreach($solicitudes as $solicitud)
        {            
            if($numero_solicitud != $solicitud->numero_solicitud){
                
                if($orden_str != ''){                     
                    $solicitud_compuesta['ordenes'] = Str::replaceLast(',', '', $ordencont);                       
                     
                    $Array_solicitudes->push($solicitud_compuesta);
                    
                    $orden_str = '';
                    $ordencont = '';
                    $totalGeneral = 0;
                }
                $solicitud_compuesta['solicitude_id'] = $solicitud->solicitude_id;
                $solicitud->ordene_id == null ? $solicitud_compuesta['ordene_id'] = 0 : $solicitud_compuesta['ordene_id'] = $solicitud->ordene_id;
                $solicitud_compuesta['numero_solicitud'] = $solicitud->numero_solicitud;
                $solicitud_compuesta['nombre_cliente'] = $solicitud->nombre_cliente;
                $solicitud_compuesta['telefono'] = $solicitud->telefono;
                $solicitud_compuesta['fecha'] = $solicitud->updated_at;
                $solicitud_compuesta['confirmado'] = $solicitud->confirmado;
                $numero_solicitud = $solicitud->numero_solicitud; 
                
                $totalGeneral == 0 ? $totalGeneral = $solicitud->precioProducto * $solicitud->cantidad : $totalGeneral += $solicitud->precioProducto * $solicitud->cantidad; 
                
            }
            else
                $totalGeneral += $solicitud->precioProducto * $solicitud->cantidad;
            
            
            if ($solicitud->cantidad != null) {

                $totalGeneralStr = $totalGeneral;
                if ($tarifa_actual == null) { 
                    
                    $solicitud->nombreMoneda == null ? $totalGeneralStr = $totalGeneralStr.$totalGeneral : $totalGeneralStr = $totalGeneral.' '.$solicitud->nombreMoneda;  
                    
                } else {
                    $totalGeneralStr = $solicitud->nombreMoneda.' $'.$totalGeneral;
                } 

                $solicitud_compuesta['totalGeneral'] = $totalGeneralStr;
                $orden_str = $solicitud->nombreProducto.' Pre: '.$solicitud->precioProducto.$solicitud->nombreMoneda.' Cant: '.$solicitud->cantidad;
            }
            else {
                $solicitud_compuesta['totalGeneral'] = '0';
                $orden_str = 'SIN ORDEN';
            }
            $ordencont = $ordencont.$orden_str.',';
        }
        
        if($solicitudes->count() == 0)
        {
            $solicitud_compuesta['solicitude_id'] = 0;
            $solicitud_compuesta['confirmado'] = 0;
        }
                
        $solicitud_compuesta['ordenes'] = Str::replaceLast(',', '', $ordencont);
        $Array_solicitudes->push($solicitud_compuesta);
        
        return  datatables()->collection($Array_solicitudes)
                ->addColumn('action','actions')
                ->toJson();

    }

    public function listado_Ord_Confirmada()
    {
        Session::put('eliminar', '');
        Session::put('disponible', '');

        

        return view('ordene.indexconfirmada');
    }

}


