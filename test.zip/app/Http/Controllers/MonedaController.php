<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Moneda;
use App\Models\Solicitude;
use Illuminate\Support\Facades\Session;

class MonedaController extends Controller
{

    public function monedas(){

        Session::put('TypeController', 'Moneda');

        return datatables()->eloquent(Moneda::query())
                           ->orderColumn('updated_at', 'desc')
                           ->addColumn('action','actions')
                           ->toJson();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('moneda.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $monedas = Moneda::where('moneda_base',true)->get()->count();
        $haymoneda_base = false;
        if(Moneda::where('moneda_base',true)->get()->count() > 0){//Existe ya una moneda base
            $haymoneda_base = true;             
        }
        return view('moneda.create',compact('haymoneda_base'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|max:20|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)'   
        ]);
        

        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Información',
            'message'  => 'Ya la moneda se encuentra registrada.'
        );

        if(Moneda::where('nombre',$request->nombre)->get()->count() > 0){
            return redirect('/monedas/create')->with($message);
        }

        if($request->monedabase[0] == "0"){
            Moneda::create([
                'nombre' => $request->nombre,
                'moneda_base' => false,
            ]);
        }
        else{
            Moneda::create([
                'nombre' => $request->nombre,
                'moneda_base' => true,
            ]);
        }
        
        return redirect('/monedas');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $moneda = Moneda::find($id);

        return view('moneda.edit')->with('moneda',$moneda);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Moneda $moneda)
    {
        $request->validate([
            'nombre' => 'required|max:20|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)'   
        ]);

        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Información',
            'message'  => 'Ya la moneda se encuentra registrada.'
        );
        
        if(Moneda::where('nombre',$request->nombre)->get()->count() > 0 && 
            $request->nombre != $moneda->nombre){
            return redirect('/monedas')->with($message);
        } 

        $moneda->nombre = $request->nombre;
        $moneda->touch();

        return redirect('/monedas');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $moneda = Moneda::find($id); 
        $solicitud = Solicitude::where('moneda_id',$id)->first();

        if($moneda->PlanesPri()->count() > 0 || $moneda->PlanesSec()->count() > 0){
            
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Error',
                'message'  => 'No puede eliminar la moneda porque esta asignada a un plan de tarifas.'
            );
            
            return redirect('/monedas')->with($message);
        }
        if($solicitud != null){
            
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Error',
                'message'  => 'No puede eliminar la moneda porque esta asignada a una orden registrada.'
            );
            
            return redirect('/monedas')->with($message);
        }
        
        $moneda->delete();
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Eliminado!',
            'message'  => 'Su registro ha sido eliminado.'
        );
        return redirect('/monedas')->with($message);
    }
}
