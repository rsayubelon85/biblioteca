<?php

namespace App\Http\Controllers;

use App\Http\Requests\RulesProductos;
use App\Models\Categoria;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;

class ProductoController extends Controller
{
    public function productos()
    {
        Session::put('TypeController', 'Producto');

        $productos = DB::table('productos')
                                ->join('categorias','categorias.id','=','productos.categoria_id')
                                ->select('productos.id','productos.nombre as nombreProducto','imagen','precio','disponibilidad','descripcion','categorias.nombre as nombreCategoria')
                                ->get();
        foreach ($productos as $producto) {
            if (!Str::contains($producto->imagen,'http')) {
                $producto->imagen = 'imagen/'.$producto->imagen;
            }
        }
        
        return datatables()->collection($productos)
                           ->addColumn('action','actions')
                           ->toJson();
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('producto.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categorias = Categoria::all();
        return view('producto.create',compact('categorias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RulesProductos $request)
    {   
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Error',
            'message'  => 'Ya el producto se encuentra registrado.'
        );
        
        if(Producto::where('nombre',$request->nombre)->get()->count() > 0){
            return redirect('/productos/create')->with($message);//Ya el producto se encuentra registrado.
        }

        //Procesamiento de la imagen
        if($imagen = $request->file('imagen')){
            $rutaguardarimagen = 'imagen/';
            $imagenproducto = date('YmdHis').".".$imagen->getClientOriginalExtension();
            $imagen->move($rutaguardarimagen,$imagenproducto);
            $producto['imagen'] = "$imagenproducto";
        }
        else{
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'info',
                'title'    => 'Información',
                'message'  => 'Debe seleccionar una imagen.'
            );
            return redirect('/productos/create')->with($message);
        }
        $producto['slug'] = Str::slug($request->nombre,'-');
        
        Producto::create([
            'nombre' => $request->nombre,
            'slug' => Str::slug($request->nombre,'-'),
            'precio' => $request->precio,
            'disponibilidad' => $request->disponibilidad,
            'descripcion' => $request->descripcion,
            'imagen' => $imagenproducto,
            'categoria_id' => $request->categorias[0]
        ]);

        return redirect()->route('productos.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $producto = Producto::find($id);
        
        $categorias = Categoria::all();
        return view('producto.edit',compact('producto','categorias'));
    }

    public function edit_pre_disp_product($id)
    {
        $producto = Producto::find($id);
        $nombreProducto = $producto->nombre;
        $precio = $producto->precio;        
        $disponibilidad = $producto->disponibilidad;

        //return $nombreProducto.' '.$precio.' '.$disponibilidad;
        
        return view('producto.editpd',compact('nombreProducto','precio','disponibilidad'));
    }

    public function update_img_product(Request $request,$nombreProducto)
    {
        $producto = Producto::where('nombre',$nombreProducto)->first();
        $producto->precio = $request["precio"];
        $producto->disponibilidad = $request["disponibilidad"];

        $producto->touch();

        return redirect()->route('productos.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RulesProductos $request, Producto $producto)
    {
        //Procesamiento de la imagen     
        $producto->nombre = $request->nombre;
        $producto->slug = Str::slug($request->nombre,'-');
        $producto->precio = $request->precio;
        $producto->disponibilidad = $request->disponibilidad;
        $producto->descripcion = $request->descripcion;
        $producto->categoria_id = $request->categorias[0];
        $producto->touch();

        return redirect()->route('productos.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $producto = Producto::find($id); 
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Error',
            'message'  => 'No puede eliminar el producto porque está asignado a una orden.'
        );
        
        if($producto->Ordenes()->count() > 0){
            return redirect('/productos')->with($message);
        }
        
        $producto->delete();
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Eliminado!',
            'message'  => 'Su registro ha sido eliminado.'
        );
        return redirect('/productos')->with($message);
    }
}
