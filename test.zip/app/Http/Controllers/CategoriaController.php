<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use App\Http\Requests\RulesCategoria;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Session;

class CategoriaController extends Controller
{    

    public function categorias(){

        Session::put('TypeController', 'Categoria');

        return datatables()->eloquent(Categoria::query())
                           ->orderColumn('updated_at', 'desc')
                           ->addColumn('action','actions')
                           ->toJson();
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    { 
        return view('categoria.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categoria.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(RulesCategoria $request)
    {
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Información',
            'message'  => 'Ya la categoria se encuentra registrada.'
        );
        
        if(Categoria::where('nombre',$request->nombre)->get()->count() > 0){
            return redirect('/categorias/create')->with($message);//Ya la categoria se encuentra registrada.
        }

        Categoria::create([
            'nombre' => $request->nombre,
            'slug' => Str::slug($request->nombre,'-'),
        ]);

        return redirect('/categorias');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        /*$categoria = Categoria::find($id);
        return view('categorias.show',compact('categoria'));*/
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categoria = Categoria::find($id);

        return view('categoria.edit')->with('categoria',$categoria);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(RulesCategoria $request, Categoria $categoria)
    {
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Información',
            'message'  => 'Ya la categoria se encuentra registrada.'
        );
        
        if(Categoria::where('nombre',$request->nombre)->get()->count() > 0 && 
            $request->nombre != $categoria->nombre){
            return redirect('/categorias/create')->with($message);//Ya la categoria se encuentra registrada.
        } 

        $categoria->nombre = $request->nombre;
        $categoria->touch();

        return redirect('/categorias');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $categoria = Categoria::find($id); 
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Error',
            'message'  => 'No puede eliminar la categoria porque esta asignada a un producto.'
        );
        
        if($categoria->Productos()->count() > 0){
            return redirect('/categorias')->with($message);
        }
        
        $categoria->delete();
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Eliminado!',
            'message'  => 'Su registro ha sido eliminado.'
        );
        return redirect('/categorias')->with($message);
    }
}
