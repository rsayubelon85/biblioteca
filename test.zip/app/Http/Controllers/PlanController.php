<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Plan;
USE App\Models\Moneda;
use App\Models\Tarifario;
use Illuminate\Support\Facades\Session;

class PlanController extends Controller
{
    public function planes()
    {
        Session::put('TypeController', 'Plan');

        $plans = collect();        

        $planes = Plan::all();
        foreach ($planes as $plan) {
            $pl = new Plan();
            $pl['id'] = $plan->id;
            $pl['moneda_base'] = $plan->MonedaPri->nombre;
            $pl['moneda_secundaria'] = $plan->MonedaSec->nombre;
            $pl['valor_cambio'] = $plan->valor_cambio;
            $plans->push($pl);
        }
        return datatables()->collection($plans)
                           ->addColumn('action','actions')
                           ->toJson();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Session::put('eliminar', '');
        return view('plan.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Moneda::where('moneda_base',true)->get()->count() == 0 || Moneda::all()->count() == 0){//No existe una moneda base
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'exito',
                'title'    => 'Disponibilidad!',
                'message'  => 'No existen monedas creadas y debe de escoger una Moneda Base antes de crear la tarifa',
                'NS'       => ''
            );
            return redirect('/plans')->with($message);         
        }
        if(Moneda::where('moneda_base',true)->get()->count() == 0)
            $moneda_base = 'No';
        else
            $moneda_base = Moneda::where('moneda_base',true)->get()[0]->nombre;
        $monedas_secundarias = Moneda::where('moneda_base',false)->get();

        return view('plan.create',compact('moneda_base','monedas_secundarias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
           'valor_cambio' => 'required|numeric'
        ]);
        
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Error',
            'message'  => 'Ya el plan se encuentra registrado.'
        );
        $moneda_base = Moneda::where('moneda_base',true)->get()[0]->id;
        $moneda_sec = Moneda::find($request->moneda_select[0])->id;
        
        if(Plan::where('moneda_primaria_id',$moneda_base)->
                 where('moneda_secundaria_id',$moneda_sec)->
                 where('valor_cambio',$request->valor_cambio)->get()->count() > 0){

            return redirect('/plans/create')->with($message);//Ya el producto se encuentra registrado.
        }
        $plan = new Plan();
        $plan->moneda_primaria_id = $moneda_base;
        $plan->moneda_secundaria_id = $moneda_sec;
        $plan->valor_cambio = $request->valor_cambio;
        $plan->save();

        $planes = Plan::all();

        return view('plan.index',compact('planes'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $plan = Plan::find($id);
        $monedas = Moneda::where('id','<>',$plan->moneda_primaria_id)->where('id','<>',$plan->moneda_secundaria_id)->get();
        return view('plan.edit',compact('plan','monedas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
           'valor_cambio' => 'required|numeric'
        ]);
        
        $moneda_base = Moneda::where('moneda_base',true)->get()[0]->id;
        $moneda_sec = Moneda::find($request->moneda_select[0])->id;
        
        $plan = Plan::find($id);
        $plan->moneda_secundaria_id = $moneda_sec;
        $plan->valor_cambio = $request->valor_cambio;
        $plan->touch();

        $planes = Plan::all();

        return view('plan.index',compact('planes'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $plan = Plan::find($id);
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'error',
            'title'    => 'Error',
            'message'  => 'El plan no se puede eliminar porque se encuentra asignado a una tarifa.'
        );

        if($plan->Tarifarios()->count() > 0)
            return redirect('/plans')->with($message);

        $plan->delete();
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Eliminado!',
            'message'  => 'Su registro ha sido eliminado.'
        );
        return redirect('/plans')->with($message);
    }
}
