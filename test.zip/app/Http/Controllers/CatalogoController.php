<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Producto;
use App\Models\Ordene;
use App\Models\Solicitude;
use App\Mail\DatosSolicitudMaillable;
use App\Models\Moneda;
use App\Models\Tarifa;
use App\Models\Tarifario;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CatalogoController extends Controller
{
    
    public function productos_catalogo()
    {
        Session::put('TypeController', 'Catalogo');

        $productos = DB::table('productos')
                                ->join('categorias','categorias.id','=','productos.categoria_id')
                                ->select('productos.id','productos.nombre as nombreProducto','imagen','precio','disponibilidad','descripcion','categorias.nombre as nombreCategoria')
                                ->where('disponibilidad','>',0)
                                ->where('productos.precio','>',0)
                                ->get();
        
        foreach ($productos as $producto) {
            if (!Str::contains($producto->imagen,'http')) {
                $producto->imagen = 'imagen/'.$producto->imagen;
            }
        }

        return  datatables()->collection($productos)
                            ->addColumn('action','actions')
                            ->toJson();
                            
    }  
    public function index(){


        $solicitud = new Solicitude();        
        
        $moneda = Moneda::where('moneda_base',true)->first();
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>',now())->first();
        
        
        if(session('NS') == null)
        {
            $numero_solicitud = 'RS-'.Str::random(10).(string)date('YmdHis');            
            $solicitud->numero_solicitud = $numero_solicitud;
            $solicitud->confirmado = false;

            if($tarifa_actual == null)//Es que no existen tarifas creadas
                $solicitud->tarifa_id = null;
            else
                $solicitud->tarifa_id = $tarifa_actual->id;
            
            if($moneda == null)//Esque no existe moneda Base creada
                $solicitud->moneda_id = null;
            else
                $solicitud->moneda_id = $moneda->id;
            $solicitud->save();
            Session::put('numero_solicitud', $numero_solicitud);
            $ordenes = $solicitud->Ordenes();            
        }
        else{
            if(str_split(session('NS'),2)[0] == "RS")   //Viene el numero_solicitud y hace falta que se mantenga la vista con todos los datos
            {
                $numero_solicitud = session('NS');
                $solicitud = Solicitude::where('numero_solicitud',$numero_solicitud)->first(); 
                $ordenes = Ordene::where('solicitude_id',$solicitud->id)->get();  
            }
            else{//Viene nuevo es necesario reinicializar los datos de la orden
                $numero_solicitud = 'RS-'.Str::random(10).(string)date('YmdHis');            
                $solicitud->numero_solicitud = $numero_solicitud;
                $solicitud->confirmado = false;
                
                if($moneda == null)//Esque no existe moneda Base creada
                    $solicitud->moneda_id = null;
                else
                    $solicitud->moneda_id = $moneda->id;
                
                if($tarifa_actual == null)//Es que no existen tarifas creadas
                    $solicitud->tarifa_id = null;
                else
                    $solicitud->tarifa_id = $tarifa_actual->id;
                                
                $solicitud->save();
                Session::put('numero_solicitud', $numero_solicitud);
                $ordenes = $solicitud->Ordenes();                
            }            
        }
        
        $productos = Producto::where('disponibilidad','>','0')->where('precio','>','0')->orderBy('updated_at','Desc')->get();
        $productos = Producto::where('disponibilidad','>','0')->where('precio','>','0')->orderBy('id','Desc')->paginate(Producto::count());

        $productosSelect = array();
    
        $totalGeneral = 0;
        $totalGeneralStr = '0';

        foreach($ordenes as $orden){
            $producto = Producto::find($orden->producto_id);
            $producto['disponibilidad'] = $orden->cantidad;
            array_push($productosSelect,$producto);

            $totalGeneral += $producto->precio * $orden->cantidad;

        }
        if($moneda == null)                
            $totalGeneralStr = $totalGeneralStr.$totalGeneral;                 
        else
            $totalGeneralStr = $totalGeneral.' '.$moneda->nombre;
        
        return view('index',compact('productos','productosSelect','numero_solicitud','totalGeneralStr'));
    }

//-----Agregar producto al carrito
    public function add_solicitud_orden(Request $request, $id){
       
        $producto = Producto::find($id);
        $numero_solicitud = Session::get('numero_solicitud');

        $productosSelect = array();
        $totalGeneral = 0;
        $totalGeneralStr = '0';
        
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>=',now())->first();
        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Disponibilidad!',
            'message'  => 'El producto ya no tiene disponibilidad',
            'NS'       => $numero_solicitud
        );             
        
        $orden = new Ordene();
        $solicitud = Solicitude::where('numero_solicitud',$numero_solicitud)->get()[0];
        
        $ordenes = Ordene::where('solicitude_id',$solicitud->id)->where('producto_id',$producto->id)->get();
                
        if($solicitud->Ordenes->where('producto_id',$producto->id)->count() == 0)   //La solicitud no tiene orden con producto
        {
            if($producto->disponibilidad == 0)
            {
                return redirect('/catalogo')->with($message);
            } 
            $orden->solicitude_id = $solicitud->id;
            $orden->producto_id = $producto->id;
            $orden->cantidad = 1;            
        }
        else{
            foreach ($solicitud->Ordenes as $ordenS) {
                if($ordenS->producto_id == $producto->id){
                    $orden = $ordenS;
                    break;
                }
            }
            if ($orden != null) {
                $orden->cantidad += 1;
            }
            else{
                $request["disponibilidad"] == null ? $orden->cantidad = 1 : $orden->cantidad = $request["disponibilidad"];  
            }
            
            if($producto->disponibilidad == 0 || $orden->cantidad >= $producto->disponibilidad)
            {
                $productos = Producto::where('disponibilidad','>','0')->where('precio','>','0')->orderBy('id','Desc')->paginate(Producto::count());
                $ordenes = Ordene::where('solicitude_id',$solicitud->id)->get();      
        
                foreach($ordenes as $orden){
                    $producto = Producto::find($orden->producto_id);
                    $producto->disponibilidad = $orden->cantidad;
                    if (!Str::contains($producto->imagen,'http')) {
                        $producto->imagen = 'imagen/'.$producto->imagen;
                    }
                    array_push($productosSelect,$producto);

                    $totalGeneral += $producto->precio * $orden->cantidad;
                }
                return redirect('/catalogo')->with($message);
            }
        }
        $orden->save();

        $productos = Producto::where('disponibilidad','>','0')->where('precio','>','0')->orderBy('id','Desc')->paginate(Producto::count());
        $ordenes = Ordene::where('solicitude_id',$solicitud->id)->get();      

        foreach($ordenes as $orden){
            
            //$producto = Producto::find($orden->producto_id);
            $orden->Producto->disponibilidad = $orden->cantidad;
            if (!Str::contains($orden->Producto->imagen,'http')) {
                $orden->Producto->imagen = 'imagen/'.$orden->Producto->imagen;
            }
            array_push($productosSelect,$orden->Producto);
            $totalGeneral += $orden->Producto->precio * $orden->cantidad;
        }
        $moneda = Moneda::where('moneda_base',true)->first();
        $totalGeneralStr = $totalGeneral;

        if ($tarifa_actual == null) {            
            if($moneda == null)                
                $totalGeneralStr = $totalGeneralStr.$totalGeneral;                 
            else
                $totalGeneralStr = $totalGeneral.' '.$moneda->nombre;
        
        } else {
            $tarifarios = Tarifario::where('tarifa_id',$tarifa_actual->id)->get();
            $totalGeneralStr = $totalGeneral.' '.$moneda->nombre;
            $operacion = '';
            if($tarifa_actual->variacion_precio > 0){
                $operacion = 'Aumento: '.$tarifa_actual->variacion_precio.'% ->'.$totalGeneral+($totalGeneral*$tarifa_actual->variacion_precio/100).' '.$moneda->nombre;
            }
            if($tarifa_actual->variacion_precio < 0){
                $operacion = 'Descuento: '.$tarifa_actual->variacion_precio.'% ->'.$totalGeneral+($totalGeneral*$tarifa_actual->variacion_precio/100).' '.$moneda->nombre;
            }
            $totalGeneralStr = $totalGeneralStr.' '.$operacion;
            if($tarifarios->count() > 0)
            {
                foreach ($tarifarios as $tarifario) {
                    
                    $totalGeneralStr = $totalGeneralStr.' '.$totalGeneral*$tarifario->Plan->valor_cambio.' '.$tarifario->Plan->MonedaSec->nombre; 
                }
            }
        }
              
        return view('index',compact('productosSelect','numero_solicitud','totalGeneralStr'));

    }

    //Eliminar productos del carrito
    public function del_solicitud_orden(Producto $producto,$numero_solicitud){
       
        
        $orden = new Ordene();
        $solicitud = Solicitude::where('numero_solicitud',$numero_solicitud)->get()[0];
        
        $orden = Ordene::where('solicitude_id',$solicitud->id)->where('producto_id',$producto->id)->get()[0];

        $totalGeneralStr = '0';
        $tarifa_actual = Tarifa::where('fecha_inicial','<=',now())->where('fecha_final','>',now())->first();
        
        if($orden->cantidad > 1)   //La solicitud no tiene orden con producto
        {
            $orden->cantidad -= 1; 
            $orden->save();           
        }
        else{
            $orden->delete();
        }

        $productos = Producto::where('disponibilidad','>','0')->where('precio','>','0')->orderBy('id','Desc')->paginate(Producto::count());
        $ordenes = Ordene::where('solicitude_id',$solicitud->id)->get();

        $productosSelect = array();
        $totalGeneral = 0;

        foreach($ordenes as $orden){
            $producto = Producto::find($orden->producto_id);
            $producto->disponibilidad = $orden->cantidad;
            if (!Str::contains($producto->imagen,'http')) {
                $producto->imagen = 'imagen/'.$producto->imagen;
            }
            array_push($productosSelect,$producto);
            $totalGeneral += $producto->precio * $orden->cantidad;
        }
        $moneda = Moneda::where('moneda_base',true)->first();
        $totalGeneralStr = $totalGeneral;

        if ($tarifa_actual == null) {            
            if($moneda == null)                
                $totalGeneralStr = $totalGeneralStr.$totalGeneral;                 
            else
                $totalGeneralStr = $totalGeneral.' '.$moneda->nombre;
        
        } else {
            $tarifarios = Tarifario::where('tarifa_id',$tarifa_actual->id)->get();
            $totalGeneralStr = $totalGeneral.' '.$moneda->nombre;
            $operacion = '';
            if($tarifa_actual->variacion_precio > 0){
                $operacion = 'Aumento: '.$tarifa_actual->variacion_precio.'% ->'.$totalGeneral+($totalGeneral*$tarifa_actual->variacion_precio/100).' '.$moneda->nombre;
            }
            if($tarifa_actual->variacion_precio < 0){
                $operacion = 'Descuento: '.$tarifa_actual->variacion_precio.'% ->'.$totalGeneral+($totalGeneral*$tarifa_actual->variacion_precio/100).' '.$moneda->nombre;
            }
            $totalGeneralStr = $totalGeneralStr.' '.$operacion;
            if($tarifarios->count() > 0)
            {
                foreach ($tarifarios as $tarifario) {
                    
                    $totalGeneralStr = $totalGeneralStr.' '.$totalGeneral*$tarifario->Plan->valor_cambio.' '.$tarifario->Plan->MonedaSec->nombre; 
                }
            }
        }


        return view('index',compact('productos','productosSelect','numero_solicitud','totalGeneralStr'));

    }

    public function actualizar_solicitud(Request  $request,$numero_solicitud)
    {
        $request->validate([
            'nombre' => 'required|max:50|regex:([a-zA-ZñÑáéíóúÁÉÍÓÚ\s]+)',
            'telefono' => 'required|max:100000000|numeric',
            'correo' => 'required|email'
        ]);

        $solicitud = Solicitude::where('numero_solicitud',$numero_solicitud)->first();
        $solicitud->nombre_cliente = $request->nombre;
        $solicitud->telefono = $request->telefono;
        $solicitud->correo = $request->correo;
        $solicitud->direccion = $request->direccion;

        $solicitud->save();

        $message = array(
            'eliminar' => 'ok',
            'type'     => 'exito',
            'title'    => 'Enviado!',
            'message'  => 'Su solicitud está siendo procesada, se le envió a su correo y un mensaje a su whatsapp con los datos de su compra, debe esperar correo o notificación confirmándole o no su pedido.',
            'NS'       => 'nuevoSI'
        );
        //$correo_destino = 'rsayubelon85@gmail.com';
        //Mail::to($correo_destino)->send(new DatosSolicitudMaillable());
        
        return redirect('/catalogo')->with($message);
        
    }
}
