<?php

namespace App\Http\Controllers;

use App\Models\Plan;
use App\Models\Solicitude;
use App\Models\Tarifa;
use Illuminate\Http\Request;
use App\Models\Tarifario;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;

class TarifarioController extends Controller
{
    public function tarifarios()
    {
        Session::put('TypeController', 'Tarifario');

        $tarifarios = Tarifario::all();
        $tarifarios_arr = array();
        $plancont = '';
        $tarifa_id = 0;

        
        foreach($tarifarios as $tarifario)
        {            
            if($tarifa_id != $tarifario->tarifa_id)
            {
                if($plancont != ''){
                    $tar_compuesto['planT'] = Str::replaceLast(',', '', $plancont);
                     
                    array_push($tarifarios_arr,$tar_compuesto);
                    
                    $plancont = '';
                }
                $tar_compuesto['id'] = $tarifario->Tarifa->id;
                $tar_compuesto['nombre'] = $tarifario->Tarifa->nombre;
                $tarifa_id = $tarifario->tarifa_id;
               
            }
            
            $planstr = $tarifario->Plan->MonedaPri->nombre.'->'.$tarifario->Plan->valor_cambio.$tarifario->Plan->MonedaSec->nombre;
            
            $plancont = $plancont.$planstr.',';
        }
        
        $tar_compuesto['planT'] = Str::replaceLast(',', '', $plancont);
        array_push($tarifarios_arr,$tar_compuesto);

        return datatables()->collection($tarifarios_arr)
                           ->addColumn('action','actions')
                           ->toJson();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        Session::put('eliminar', '');     
        return view('tarifario.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tarifas = Tarifa::all();
        $planes = Plan::all();
        if($tarifas->count() == 0){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'info',
                'title'    => 'Tarifas!',
                'message'  => 'No existen tarifas creadas, por favor cree al menos una.',
                'NS'       => ''
            );
            return redirect('/tarifarios',compact('message'));         
        }
        if($planes->count() == 0){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'info',
                'title'    => 'Tarifas!',
                'message'  => 'No existen planes creados, por favor cree al menos uno.',
                'NS'       => ''
            );
            return redirect('/tarifarios',compact('message'));         
        }

        return view('tarifario.create',compact('tarifas','planes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tarifa = Tarifa::find($request['tarifa']);
        $planes_id = $request['plan'];
        if($planes_id == null){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Tarifario!',
                'message'  => 'Debe asignar al menos un plan',
                'NS'       => ''
            );
            return redirect('/tarifarios/create')->with($message);            
        }
        for ($i=0; $i < count($planes_id); $i++) { 
            
            if(Tarifario::where('tarifa_id',$tarifa->id)->where('plan_id',$planes_id[$i])->count() > 0){
                
                $message = array(
                    'eliminar' => 'ok',
                    'type'     => 'error',
                    'title'    => 'Tarifario!',
                    'message'  => 'La tarifa '.$tarifa->nombre.' ya tiene asignado el plan '.$planes_id[$i],
                    'NS'       => ''
                );
                return redirect('/tarifarios/create')->with($message);         
            }
            $plan = Plan::find($planes_id[$i]);
            $Tars = Tarifario::where('tarifa_id',$tarifa->id)->get();
            
            foreach($Tars as $Tar){
                $planT = Plan::find($Tar->plan_id);
                if($plan->MonedaSec->id == $planT->MonedaSec->id){

                    $message = array(
                        'eliminar' => 'ok',
                        'type'     => 'error',
                        'title'    => 'Tarifario!',
                        'message'  => 'La tarifa '.$tarifa->nombre.' ya tiene un plan '.$planT->id.' con la misma moneda del plan '.$plan->id.' que estas insertando',
                        'NS'       => ''
                    );
                    return redirect('/tarifarios/create')->with($message);   
                }     
            }
            $tarifario = new Tarifario();
            $tarifario->tarifa_id = $tarifa->id;
            $tarifario->plan_id = $planes_id[$i];
            
            $tarifario->save();
        }
        return redirect('/tarifarios');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tarifa = Tarifa::find($id);
        $planesTar = Tarifario::where('tarifa_id',$id)->get();
        $planes = Plan::all();
        foreach ($planes as $plan) {
            if($planesTar->where('plan_id',$plan->id)->count() > 0)
                $plan['checked'] = true;
            else
                $plan['checked'] = false;
        }
        return view('tarifario.edit',compact('tarifa','planes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tarifa = Tarifa::find($id);
        $planes_id = $request['plan'];
        if($planes_id == null){
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Tarifario!',
                'message'  => 'Debe asignar al menos un plan',
                'NS'       => ''
            );
            return redirect('/tarifarios/'.$id.'/edit')->with($message);            
        }

        for ($i=0; $i < count($planes_id); $i++) { 
            $plan = Plan::find($planes_id[$i]);

            for ($j=0; $j < count($planes_id); $j++) { 
                $planD = Plan::find($planes_id[$j]);
                if($plan->id <> $planD->id)
                {
                    if($plan->MonedaSec->id == $planD->MonedaSec->id){

                        $message = array(
                            'eliminar' => 'ok',
                            'type'     => 'error',
                            'title'    => 'Tarifario!',
                            'message'  => 'La tarifa '.$tarifa->nombre.' ya tiene un plan '.$planD->id.' con la misma moneda del plan '.$plan->id.' que estas insertando',
                            'NS'       => ''
                        );
                        return redirect('/tarifarios/'.$id.'/edit')->with($message);   
                    } 
                }
            }
        }

        $Tars = Tarifario::where('tarifa_id',$tarifa->id)->get();

        foreach($Tars as $Tar)
        {
            $Tar->delete();
        }
        for ($i=0; $i < count($planes_id); $i++) {
            $tarifario = new Tarifario();
            $tarifario->tarifa_id = $tarifa->id;
            $tarifario->plan_id = $planes_id[$i];
            
            $tarifario->touch();
        }
        return redirect('/tarifarios');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Revisar si existe alguna solicitud que tenga esta tarifa
        $solicitudes = Solicitude::where('tarifa_id',$id);
        if($solicitudes->count() > 0)
        {
            $message = array(
                'eliminar' => 'ok',
                'type'     => 'error',
                'title'    => 'Tarifario!',
                'message'  => 'No puede dejar de asignar esta tarifa debido a que esta asosiada a una orden ya registrada',
                'NS'       => ''
            );
            return redirect('/tarifarios')->with($message); 
        }
        $Tarifarios = Tarifario::where('tarifa_id',$id);
        $Tarifarios->delete();
        
        return redirect('/tarifarios');

    }
}
