<?php

use App\Http\Controllers\CatalogoController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\MonedaController;
use App\Http\Controllers\OrdeneController;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\TarifaController;
use App\Http\Controllers\TarifarioController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    return redirect('/catalogo');
    //$productos = Producto::all();
    //return view('producto.index',compact('productos'));//return view('welcome');
});

Route::get('categorias/cats',[CategoriaController::class,'categorias'])->name('datatable.cats');

Route::resource('categorias',CategoriaController::class);


Route::get('monedas/mds',[MonedaController::class,'monedas'])->name('datatable.mds');

Route::resource('monedas',MonedaController::class);


Route::get('tarifas/tar',[TarifaController::class,'tarifas'])->name('datatable.tar');

Route::resource('tarifas',TarifaController::class);


Route::get('plans/plan',[PlanController::class,'planes'])->name('datatable.plan');

Route::resource('plans',PlanController::class);


Route::get('tarifarios/tarf',[TarifarioController::class,'tarifarios'])->name('datatable.tarifario');

Route::resource('tarifarios',TarifarioController::class);


Route::controller(ProductoController::class)->group(function(){

    Route::get('productos/prod','productos')->name('datatable.producto');

    Route::get('productos/{producto}/editpd','edit_pre_disp_product')->name('product.editpd');

    Route::put('productos/{nombreProducto}','update_img_product')->name('products.updatepd');

});


Route::resource('productos',ProductoController::class);


Route::controller(CatalogoController::class)->group(function(){

    Route::get('catalogo','index')->name('catalogo.index');

    Route::get('catalogo/prod','productos_catalogo');

    Route::get('catalogo/{id}','add_solicitud_orden')->name('catalogo.select');

    Route::get('catalogo/{producto}/{numero_solicitud}/del','del_solicitud_orden')->name('catalogo.noselect');

    Route::put('catalogo/{numero_solicitud}','actualizar_solicitud')->name('catalogo.updatesolicitud');
});

Route::controller(OrdeneController::class)->group(function(){    

    Route::get('ordene','index')->name('orden.index');

    Route::get('ordene/ord','ordenes');

    Route::get('ordene/ordconf','ordenes_Confirmadas');

    Route::get('ordene/prod','productos_ordenes');

    Route::delete('ordene/{id}/ord','destroy_Ord')->name('ordene.eliminarorden');

    Route::get('ordene/sel/{solicitude_id}','confirmar_orden')->name('ordene.confirmar');

    Route::put('ordene/{id}','update_Cant')->name('ordene.updatecant');    

    Route::get('ordene/edit/{solicitude_id}','edit')->name('ordene.edit');

    Route::get('ordene/show/{id_sol}','Show_Ord')->name('ordene.show');

    Route::get('ordene/{id}/productos','show_Productos')->name('ordene.showProd');

    Route::delete('ordene/{id_sol}/sol','destroy')->name('ordene.destroy');

    Route::get('ordene/{id_prod}/{id_sol}','add_solicitud_orden')->name('ordene.select');

    Route::get('ordene/listado','listado_Ord_Confirmada')->name('ordene.listado');

});

//Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

