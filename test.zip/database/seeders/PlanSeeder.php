<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Plan;

class PlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $plan = new Plan();
        $plan->moneda_primaria_id = 1;
        $plan->moneda_secundaria_id = 2;
        $plan->valor_cambio = 175;
        $plan->save();

        $plan = new Plan();
        $plan->moneda_primaria_id = 1;
        $plan->moneda_secundaria_id = 3;
        $plan->valor_cambio = 1.2;
        $plan->save();

        $plan = new Plan();
        $plan->moneda_primaria_id = 1;
        $plan->moneda_secundaria_id = 4;
        $plan->valor_cambio = 1.5;
        $plan->save();
    }
}
