<?php

namespace Database\Seeders;

use App\Models\Moneda;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MonedaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $moneda = new Moneda();
        $moneda->nombre = 'usd';
        $moneda->moneda_base = true;
        $moneda->save();

        $moneda = new Moneda();
        $moneda->nombre = 'cup';
        $moneda->moneda_base = false;
        $moneda->save();
        
        $moneda = new Moneda();
        $moneda->nombre = 'mlc';
        $moneda->moneda_base = false;
        $moneda->save();

        $moneda = new Moneda();
        $moneda->nombre = 'eur';
        $moneda->moneda_base = false;
        $moneda->save();
    }
}
