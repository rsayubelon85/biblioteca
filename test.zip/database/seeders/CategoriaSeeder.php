<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categoria = new Categoria();
        $categoria->nombre = 'Miscelanias';
        $categoria->slug = 'miscelanias';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->nombre = 'Articulos de fiesta';
        $categoria->slug = 'articulos-de-fiestas';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->nombre = 'Electrodomesticos';
        $categoria->slug = 'electrodomesticos';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->nombre = 'Juguetes';
        $categoria->slug = 'juguetes';
        $categoria->save();
    }
}
