<?php

namespace Database\Seeders;

use App\Models\Tarifario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TarifarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tarifario = new Tarifario();
        $tarifario->tarifa_id = 1;
        $tarifario->plan_id = 1;
        $tarifario->activo = true;
        $tarifario->save();

        $tarifario = new Tarifario();
        $tarifario->tarifa_id = 1;
        $tarifario->plan_id = 2;
        $tarifario->activo = true;
        $tarifario->save();

        $tarifario = new Tarifario();
        $tarifario->tarifa_id = 1;
        $tarifario->plan_id = 3;
        $tarifario->activo = true;
        $tarifario->save();
    }
}
