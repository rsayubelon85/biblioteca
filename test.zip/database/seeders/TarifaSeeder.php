<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Tarifa;

class TarifaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tarifa = new Tarifa();
        $tarifa->nombre = 'Temporada Alta';
        $tarifa->fecha_inicial = '2022-06-01';
        $tarifa->fecha_final = '2022-12-31';
        $tarifa->lunes = true;
        $tarifa->martes = true;
        $tarifa->miercoles = true;
        $tarifa->jueves = true;
        $tarifa->viernes = true;
        $tarifa->sabado = true;
        $tarifa->domingo = true;
        $tarifa->variacion_precio = 1;
        $tarifa->save();
    }
}
