<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->id();           
            $table->unsignedBigInteger('moneda_primaria_id');
            $table->unsignedBigInteger('moneda_secundaria_id');
            $table->double('valor_cambio');
            $table->boolean('activo')->default(true);
            $table->timestamps();

            $table->foreign('moneda_primaria_id')->references('id')->on('monedas');
            $table->foreign('moneda_secundaria_id')->references('id')->on('monedas');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plans');
    }
};
