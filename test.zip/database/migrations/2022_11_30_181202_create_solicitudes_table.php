<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('solicitudes', function (Blueprint $table) {
            $table->id();
            $table->text('numero_solicitud',200);
            $table->string('nombre_cliente')->nullable();
            $table->integer('telefono')->nullable();
            $table->string('correo')->nullable();
            $table->text('direccion')->nullable();
            $table->unsignedBigInteger('tarifa_id')->nullable();
            $table->unsignedBigInteger('moneda_id')->nullable();            
            $table->boolean('confirmado');
            $table->timestamps();

            $table->foreign('tarifa_id')->nullable()->references('id')->on('tarifas')->constrained();
            $table->foreign('moneda_id')->nullable()->references('id')->on('monedas')->constrained();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('solicitudes');
    }
};
