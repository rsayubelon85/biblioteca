<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Producto>
 */
class ProductoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $nombre = $this->faker->text(20);
        $faker  = \Faker\Factory::create();
        $faker->addProvider(new \Smknstd\FakerPicsumImages\FakerPicsumImagesProvider($faker));
        return [
            'nombre' => $nombre,
            'slug' => Str::slug($nombre,'-'),
            'imagen' => $faker->imageUrl(150,150),
            'descripcion' => $this->faker->paragraph(),
            'disponibilidad' => $this->faker->randomNumber(),
            'precio' => $this->faker->randomFloat(2,1,10),
            'categoria_id' => mt_rand(1,4)    
        ];
    }
}
