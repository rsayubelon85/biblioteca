$(document).ready(function () {
    $('.formEliminar').submit(function(e){
        e.preventDefault(); 
        
        Swal.fire({
            title: 'Está usted seguro?',
            text: "No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, borrarlo!',
            cancelButtonText: 'Cancelar'
            }).then((result) => {
            if (result.isConfirmed) {
                
                this.submit();
            }
        })
    });

    /*if(document.getElementById("tipo_config").value == "catalogo_index")
    {
        $('#productos').DataTable({
            responsive: true,
            autoWidth: false,
            order: [[ "updated_at", "desc" ]]
        });

        $('#productosselect').DataTable({
            responsive: true,
            autoWidth: false,
            order: [[ "updated_at", "desc" ]]
        });
    }*/

      
});
function MostrarFormContact(){
    document.getElementById("formcontac").hidden = false;
}